﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;

namespace Andrew_Kerr_GameStop.Admin
{
    public partial class AddVideoGame : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            ConsoleTier consoleTier = new ConsoleTier();
            List<Console> consoleList = new List<Console>();
            consoleList = consoleTier.getAllConsoles();

            foreach (Console c in consoleList)
            {
                ddConsoleList.Items.Add(c.consoleName);
            }
        }

        protected void btnClear_Click(object sender, EventArgs e)
        {
            txtGameTitle.Text = "";
            txtGameDesc.Text = "";
            txtDeveloper.Text = "";
            txtGenre.Text = "";
            txtStockRemaining.Text = "";
            txtGameCost.Text = "";
            flGameImage = null;
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            VideoGame game = new VideoGame();
            game.gameTitle = txtGameTitle.Text;
            game.gameDesc = txtGameDesc.Text;
            game.developer = txtDeveloper.Text;
            game.genre = txtGenre.Text;
            game.stockRemaining = int.Parse(txtStockRemaining.Text);
            game.gameCost = decimal.Parse(txtGameCost.Text);

            // Image Saving
            string filePath = flGameImage.PostedFile.FileName;
            string fileName = Path.GetFileName(filePath);
            Stream fs = flGameImage.PostedFile.InputStream;

            BinaryReader br = new BinaryReader(fs);
            byte[] gameImage = br.ReadBytes((Int32)fs.Length);
            game.gameImage = gameImage;

            // Get the Console ID
            VideoGameTier tier = new VideoGameTier();
            string consoleName = ddConsoleList.SelectedValue;
            Console console = new Console();
            console = tier.getConsolebyName(consoleName);
            game.consoleID = console.consoleID;

            tier.insertVideoGame(game);

            Response.Redirect("/Admin/ViewAllVideoGames.aspx");

        }

    }
}