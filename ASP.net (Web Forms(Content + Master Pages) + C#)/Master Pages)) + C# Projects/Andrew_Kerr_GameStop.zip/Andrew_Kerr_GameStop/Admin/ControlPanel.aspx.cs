﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Andrew_Kerr_GameStop.Admin
{
    public partial class ControlPanel : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnViewCustomers_Click(object sender, EventArgs e)
        {
            Response.Redirect("/Admin/ViewAllCustomers.aspx");
        }

        protected void btnViewEmployees_Click(object sender, EventArgs e)
        {
            Response.Redirect("/Admin/ViewAllEmployees.aspx");
        }

        protected void btnAddCustomer_Click(object sender, EventArgs e)
        {
            Response.Redirect("/CustomerRegistration.aspx");
        }

        protected void btnAddEmployee_Click(object sender, EventArgs e)
        {
            Response.Redirect("/Admin/EmployeeRegistration.aspx");
        }

        protected void btnAddConsole_Click(object sender, EventArgs e)
        {
            Response.Redirect("/Admin/AddConsole.aspx");
        }

        protected void btnConsoles_Click(object sender, EventArgs e)
        {
            Response.Redirect("/Admin/ViewAllConsoles.aspx");
        }

        protected void btnAddVideoGame_Click(object sender, EventArgs e)
        {
            Response.Redirect("/Admin/AddVideoGame.aspx");
        }

        protected void btnVideoGames_Click(object sender, EventArgs e)
        {
            Response.Redirect("/Admin/ViewAllVideoGames.aspx");
        }
    }
}