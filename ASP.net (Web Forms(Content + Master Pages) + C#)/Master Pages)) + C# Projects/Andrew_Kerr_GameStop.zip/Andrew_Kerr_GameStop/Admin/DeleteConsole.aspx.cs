﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Andrew_Kerr_GameStop.Admin
{
    public partial class DeleteConsole : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            List<Console> consoleList = new List<Console>();
            ConsoleTier tier = new ConsoleTier();

            consoleList = tier.getAllConsoles();

            grdDeleteConsole.DataSource = consoleList;

            grdDeleteConsole.DataBind();
        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            Response.Redirect("/Admin/ViewAllConsoles.aspx");
        }

        protected void btnConfirm_Click(object sender, EventArgs e)
        {
            ConsoleTier tier = new ConsoleTier();
            int consoleID = int.Parse(txtConsoleID.Text);

            if (tier.getConsolebyId(consoleID) != null)
            {
                Console console = new Console();
                console = tier.getConsolebyId(consoleID);

                Session["Console"] = console;
                Response.Redirect("/Admin/DeleteConsoleConf.aspx");
            }
            else
            {
                lblInvalid.Visible = true;
            }
        }
    }
}