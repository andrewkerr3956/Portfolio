﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Andrew_Kerr_GameStop.Admin
{
    public partial class DeleteConsoleConf : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Console console= (Console)Session["Console"];
            lblConsoleName.Text = console.consoleName;
            lblConsoleDesc.Text = console.consoleDesc;
            lblManufacturer.Text = console.manufacturer;
            lblStockRemaining.Text = console.stockRemaining.ToString();
            lblConsoleCost.Text = console.consoleCost.ToString();
            imgConsole.ImageUrl = "/Handlers/consoleImage.ashx?ID= " + console.consoleID;
         
        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            Session["Console"] = null;
            Response.Redirect("/Admin/DeleteConsole.aspx");
        }

        protected void btnDelete_Click(object sender, EventArgs e)
        {
            ConsoleTier tier = new ConsoleTier();
            Console console = (Console)Session["Console"];
            int consoleID = console.consoleID;


            tier.deleteConsole(consoleID);

            Session["Console"] = null;
            Response.Redirect("/Admin/ViewAllConsoles.aspx");

            
        }
    }
}