﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Andrew_Kerr_GameStop.Admin
{
    public partial class DeleteCustomer : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            List<Customer> customerList = new List<Customer>();
            CustomerTier tier = new CustomerTier();

            customerList = tier.getAllCustomers();

            grdDeleteCustomer.DataSource = customerList;

            grdDeleteCustomer.DataBind();
        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            Response.Redirect("/Admin/ViewAllCustomers.aspx");
        }

        protected void btnConfirm_Click(object sender, EventArgs e)
        {
            CustomerTier tier = new CustomerTier();
            int custID = int.Parse(txtCustID.Text);

            if (tier.getCustomerbyId(custID) != null)
            {
                Customer customer = new Customer();
                customer = tier.getCustomerbyId(custID);

                Session["Customer"] = customer;
                Response.Redirect("/Admin/DeleteCustomerConf.aspx");
            }
            else
            {
                lblInvalid.Visible = true;
            }
        }
    }
}