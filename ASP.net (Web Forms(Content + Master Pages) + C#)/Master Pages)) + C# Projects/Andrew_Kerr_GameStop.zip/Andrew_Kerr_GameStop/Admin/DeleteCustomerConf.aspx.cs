﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Andrew_Kerr_GameStop.Admin
{
    public partial class DeleteCustomerConf : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Customer customer = (Customer)Session["Customer"];
            lblFirstName.Text = customer.firstName;
            lblMiddleName.Text = customer.middleName;
            lblLastName.Text = customer.lastName;
            lblAddress.Text = customer.address;
            lblAddress2.Text = customer.address2;
            lblCity.Text = customer.city;
            lblState.Text = customer.state;
            lblZip.Text = customer.zip.ToString();
        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            Session["Customer"] = null;
            Response.Redirect("/Admin/DeleteCustomer.aspx");
        }

        protected void btnDelete_Click(object sender, EventArgs e)
        {
            CustomerTier tier = new CustomerTier();
            Customer customer = (Customer)Session["Customer"];
            int custID = customer.custID;


            tier.deleteCustomer(custID);

            Session["Customer"] = null;
            Response.Redirect("/Admin/ViewAllCustomers.aspx");

            
        }
    }
}