﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Andrew_Kerr_GameStop.Admin
{
    public partial class DeleteEmployeeConf : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Employee employee = (Employee)Session["Employee"];
            lblFirstName.Text = employee.firstName;
            lblMiddleName.Text = employee.middleName;
            lblLastName.Text = employee.lastName;
            lblAddress.Text = employee.address;
            lblAddress2.Text = employee.address2;
            lblCity.Text = employee.city;
            lblState.Text = employee.state;
            lblZip.Text = employee.zip.ToString();
            lblHireDate.Text = employee.hireDate.ToShortDateString();
            lblEndDate.Text = employee.endDate.ToShortDateString();
            lblLocation.Text = employee.location;
        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            Session["Employee"] = null;
            Response.Redirect("/Admin/DeleteEmployee.aspx");
        }

        protected void btnDelete_Click(object sender, EventArgs e)
        {
            EmployeeTier tier = new EmployeeTier();
            Employee employee = (Employee)Session["Employee"];
            int empID = employee.empID;


            tier.deleteEmployee(empID);

            Session["Employee"] = null;
            Response.Redirect("/Admin/ViewAllEmployees.aspx");

            
        }
    }
}