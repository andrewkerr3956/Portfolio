﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Andrew_Kerr_GameStop.Admin
{
    public partial class DeleteVideoGame : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            List<VideoGame> gameList = new List<VideoGame>();
            VideoGameTier tier = new VideoGameTier();

            gameList = tier.getAllVideoGames();

            grdDeleteVideoGame.DataSource = gameList;

            grdDeleteVideoGame.DataBind();
        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            Response.Redirect("/Admin/ViewAllVideoGames.aspx");
        }

        protected void btnConfirm_Click(object sender, EventArgs e)
        {
            VideoGameTier tier = new VideoGameTier();
            int gameID = int.Parse(txtVideoGameID.Text);

            if (tier.getVideoGamebyId(gameID) != null)
            {
                VideoGame game = new VideoGame();
                game = tier.getVideoGamebyId(gameID);

                Session["VideoGame"] = game;
                Response.Redirect("/Admin/DeleteVideoGameConf.aspx");
            }
            else
            {
                lblInvalid.Visible = true;
            }
        }
    }
}