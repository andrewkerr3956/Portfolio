﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Andrew_Kerr_GameStop.Admin
{
    public partial class DeleteVideoGameConf : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            VideoGame game= (VideoGame)Session["VideoGame"];
            lblGameTitle.Text = game.gameTitle;
            lblGameDesc.Text = game.gameDesc;
            lblDeveloper.Text = game.developer;
            lblGenre.Text = game.genre;
            lblStockRemaining.Text = game.stockRemaining.ToString();
            lblGameCost.Text = game.gameCost.ToString();
            imgVideoGame.ImageUrl = "/Handlers/gameImage.ashx?ID=" + game.gameID.ToString();
            

            VideoGameTier tier = new VideoGameTier();
            Console console = tier.getConsolebyId(game.consoleID);
            lblConsoleName.Text = console.consoleName;
         
        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            Session["VideoGame"] = null;
            Response.Redirect("/Admin/DeleteVideoGame.aspx");
        }

        protected void btnDelete_Click(object sender, EventArgs e)
        {
            VideoGameTier tier = new VideoGameTier();
            VideoGame game = (VideoGame)Session["VideoGame"];
            int gameID = game.gameID;


            tier.deleteVideoGame(gameID);

            Session["VideoGame"] = null;
            Response.Redirect("/Admin/ViewAllVideoGames.aspx");

            
        }
    }
}