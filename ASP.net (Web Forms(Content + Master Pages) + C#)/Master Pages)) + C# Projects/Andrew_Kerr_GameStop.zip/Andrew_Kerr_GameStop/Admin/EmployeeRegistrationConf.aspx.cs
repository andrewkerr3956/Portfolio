﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Andrew_Kerr_GameStop.Admin
{
    public partial class EmployeeRegistrationConf : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["Employee"] != null)
            {
                Employee employee = (Employee)Session["Employee"];

                lblFirstName.Text = employee.firstName;
                lblMiddleName.Text = employee.middleName;
                lblLastName.Text = employee.lastName;
                lblAddress.Text = employee.address;
                lblAddress2.Text = employee.address2;
                lblCity.Text = employee.city;
                lblState.Text = employee.state;
                lblZipCode.Text = employee.zip.ToString();
                lblHireDate.Text = employee.hireDate.ToShortDateString();
                lblEndDate.Text = employee.endDate.ToShortDateString();
                lblLocation.Text = employee.location;

            }
            else
            {
                Response.Redirect("/Admin/EmployeeRegistration.aspx");
            }
        }

        protected void btnChange_Click(object sender, EventArgs e)
        {
            Response.Redirect("/Admin/EmployeeRegistration.aspx");
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            Employee employee = (Employee)Session["Employee"];
            EmployeeTier tier = new EmployeeTier();

            tier.insertEmployee(employee);

            Response.Redirect("/Admin/ControlPanel.aspx");
        }

    }
}