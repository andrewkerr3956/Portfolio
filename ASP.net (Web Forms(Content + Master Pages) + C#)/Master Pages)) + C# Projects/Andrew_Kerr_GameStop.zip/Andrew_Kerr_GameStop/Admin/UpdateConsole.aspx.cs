﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Andrew_Kerr_GameStop.Admin
{
    public partial class UpdateConsole : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            ConsoleTier tier = new ConsoleTier();
            List<Console> consoleList = new List<Console>();

            consoleList = tier.getAllConsoles();

            grdUpdateConsole.DataSource = consoleList;
            grdUpdateConsole.DataBind();
        }

        protected void btnConfirm_Click(object sender, EventArgs e)
        {
            ConsoleTier tier = new ConsoleTier();
            int consoleID = int.Parse(txtConsoleID.Text);

            if( tier.getConsolebyId(consoleID) != null )
            {
                Console console = new Console();
                console = tier.getConsolebyId(consoleID);

                Session["Console"] = console;
                Response.Redirect("/Admin/UpdateConsoleInfo.aspx");
            }
            else
            {
                lblInvalid.Visible = true;
            }
        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            Response.Redirect("/Admin/ViewAllConsoles.aspx");
        }
    }
}