﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;

namespace Andrew_Kerr_GameStop.Admin
{
    public partial class UpdateConsoleInfo : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["Console"] != null)
            {
                Console console = (Console)Session["Console"];
                lblConsoleID.Text = console.consoleID.ToString();
                txtConsoleName.Text = console.consoleName;
                txtConsoleDesc.Text = console.consoleDesc;
                txtManufacturer.Text = console.manufacturer;
                txtStockRemaining.Text = console.stockRemaining.ToString();
                txtConsoleCost.Text = console.consoleCost.ToString();
            }

        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            Console console = new Console();
            console.consoleName = txtConsoleName.Text;
            console.consoleDesc = txtConsoleDesc.Text;
            console.manufacturer = txtManufacturer.Text;
            console.stockRemaining = int.Parse(txtStockRemaining.Text);
            console.consoleCost = decimal.Parse(txtConsoleCost.Text);

            // Image Saving
            string filePath = flConsoleImage.PostedFile.FileName;
            string fileName = Path.GetFileName(filePath);
            Stream fs = flConsoleImage.PostedFile.InputStream;

            BinaryReader br = new BinaryReader(fs);
            byte[] consoleImage = br.ReadBytes((Int32)fs.Length);


            ConsoleTier tier = new ConsoleTier();

            console.consoleImage = consoleImage;

            tier.updateConsole(console);

            Response.Redirect("/Admin/UpdateConsole.aspx");

        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            Session["Console"] = null;
            Response.Redirect("/Admin/UpdateConsole.aspx");
        }

    }
}