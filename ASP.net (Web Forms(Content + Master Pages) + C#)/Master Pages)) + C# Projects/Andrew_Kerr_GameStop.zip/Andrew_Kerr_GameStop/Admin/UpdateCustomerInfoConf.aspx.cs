﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Andrew_Kerr_GameStop.Admin
{
    public partial class UpdateCustomerInfoConf : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["Customer"] != null)
            {
                Customer customer = (Customer)Session["Customer"];
                lblCustID.Text = customer.custID.ToString();
                lblFirstName.Text = customer.firstName;
                lblMiddleName.Text = customer.middleName;
                lblLastName.Text = customer.lastName;
                lblAddress.Text = customer.address;
                lblAddress2.Text = customer.address2;
                lblCity.Text = customer.city;
                lblState.Text = customer.state;
                lblZip.Text = customer.zip.ToString();
            }
            else
            {
                Session["Customer"] = null;
                Response.Redirect("/Admin/UpdateCustomer.aspx");
            }
        }

        protected void btnChange_Click(object sender, EventArgs e)
        {
            Response.Redirect("/Admin/UpdateCustomerInformation.aspx");
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            CustomerTier tier = new CustomerTier();
            Customer customer = (Customer)Session["Customer"];

            tier.updateCustomer(customer);

            Session["Customer"] = null;
            Response.Redirect("/Admin/ViewAllCustomers.aspx");

        }
    }
}