﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Andrew_Kerr_GameStop.Admin
{
    public partial class UpdateCustomerInformation : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["Customer"] != null)
            {
                Customer customer = (Customer)Session["Customer"];
                lblCustID.Text = customer.custID.ToString();
                txtFirstName.Text = customer.firstName;
                txtMiddleName.Text = customer.middleName;
                txtLastName.Text = customer.lastName;
                txtAddress.Text = customer.address;
                txtAddress2.Text = customer.address2;
                txtCity.Text = customer.city;
                txtState.Text = customer.state;
                txtZip.Text = customer.zip.ToString();

                Session["Customer"] = null;

            }

        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            Customer customer = new Customer();
            customer.custID = int.Parse(lblCustID.Text);
            customer.firstName = txtFirstName.Text;
            customer.middleName = txtMiddleName.Text;
            customer.lastName = txtLastName.Text;
            customer.address = txtAddress.Text;
            customer.address2 = txtAddress2.Text;
            customer.city = txtCity.Text;
            customer.state = txtState.Text;
            customer.zip = int.Parse(txtZip.Text);

            Session["Customer"] = null;
            Session["Customer"] = customer;
            Response.Redirect("/Admin/UpdateCustomerInfoConf.aspx");
        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            Session["Customer"] = null;
            Response.Redirect("/Admin/UpdateCustomer.aspx");
        }
    }
}