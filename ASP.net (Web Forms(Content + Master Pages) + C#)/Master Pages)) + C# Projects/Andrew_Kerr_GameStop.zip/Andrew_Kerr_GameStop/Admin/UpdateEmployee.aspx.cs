﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Andrew_Kerr_GameStop.Admin
{
    public partial class UpdateEmployee : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            EmployeeTier tier = new EmployeeTier();
            List<Employee> employeeList = new List<Employee>();

            employeeList = tier.getAllEmployees();

            grdUpdateEmployee.DataSource = employeeList;
            grdUpdateEmployee.DataBind();
        }

        protected void btnConfirm_Click(object sender, EventArgs e)
        {
            EmployeeTier tier = new EmployeeTier();
            int empID = int.Parse(txtEmpID.Text);

            if( tier.getEmployeebyId(empID) != null )
            {
                Employee employee = new Employee();
                employee = tier.getEmployeebyId(empID);

                Session["Employee"] = employee;
                Response.Redirect("/Admin/UpdateEmployeeInfo.aspx");
            }
            else
            {
                lblInvalid.Visible = true;
            }
        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            Response.Redirect("/Admin/ViewAllEmployees.aspx");
        }
    }
}