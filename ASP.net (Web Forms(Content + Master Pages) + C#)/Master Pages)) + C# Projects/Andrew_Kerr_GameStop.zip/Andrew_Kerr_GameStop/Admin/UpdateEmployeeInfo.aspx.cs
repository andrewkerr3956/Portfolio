﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Andrew_Kerr_GameStop.Admin
{
    public partial class UpdateEmployeeInfo : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["Employee"] != null)
            {
                Employee employee = (Employee)Session["Employee"];
                lblEmpID.Text = employee.empID.ToString();
                txtFirstName.Text = employee.firstName;
                txtMiddleName.Text = employee.middleName;
                txtLastName.Text = employee.lastName;
                txtAddress.Text = employee.address;
                txtAddress2.Text = employee.address2;
                txtCity.Text = employee.city;
                txtState.Text = employee.state;
                txtZip.Text = employee.zip.ToString();
                txtLocation.Text = employee.location;
                lblHireDate.Text = employee.hireDate.ToShortDateString();
                lblEndDate.Text = employee.endDate.ToShortDateString();

                Session["Employee"] = null;

            }

        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            Employee employee = new Employee();
            employee.empID = int.Parse(lblEmpID.Text);
            employee.firstName = txtFirstName.Text;
            employee.middleName = txtMiddleName.Text;
            employee.lastName = txtLastName.Text;
            employee.address = txtAddress.Text;
            employee.address2 = txtAddress2.Text;
            employee.city = txtCity.Text;
            employee.state = txtState.Text;
            employee.zip = int.Parse(txtZip.Text);
            employee.hireDate = DateTime.Parse(lblHireDate.Text);
            employee.endDate = DateTime.Parse(lblEndDate.Text);
            employee.location = txtLocation.Text;

            Session["Employee"] = null;
            Session["Employee"] = employee;
            Response.Redirect("/Admin/UpdateEmployeeInfoConf.aspx");
        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            Session["Employee"] = null;
            Response.Redirect("/Admin/UpdateEmployee.aspx");
        }

        protected void clndrHireDate_SelectionChanged(object sender, EventArgs e)
        {
            lblHireDate.Text = clndrHireDate.SelectedDate.ToShortDateString();
            clndrHireDate.Visible = false;
        }

        protected void clndrEndDate_SelectionChanged(object sender, EventArgs e)
        {
            lblEndDate.Text = clndrEndDate.SelectedDate.ToShortDateString();
            clndrEndDate.Visible = false;
        }

        protected void btnHireDate_Click(object sender, EventArgs e)
        {
            clndrHireDate.Visible = true;
        }

        protected void btnEndDate_Click(object sender, EventArgs e)
        {
            clndrEndDate.Visible = true;
        }
    }
}