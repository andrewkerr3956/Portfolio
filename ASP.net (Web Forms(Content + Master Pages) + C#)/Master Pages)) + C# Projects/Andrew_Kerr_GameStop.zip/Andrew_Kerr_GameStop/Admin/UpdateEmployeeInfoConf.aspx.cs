﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Andrew_Kerr_GameStop.Admin
{
    public partial class UpdateEmployeeInfoConf : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["Employee"] != null)
            {
                Employee employee = (Employee)Session["Employee"];
                lblEmpID.Text = employee.empID.ToString();
                lblFirstName.Text = employee.firstName;
                lblMiddleName.Text = employee.middleName;
                lblLastName.Text = employee.lastName;
                lblAddress.Text = employee.address;
                lblAddress2.Text = employee.address2;
                lblCity.Text = employee.city;
                lblState.Text = employee.state;
                lblZip.Text = employee.zip.ToString();
                lblLocation.Text = employee.location;
                lblHireDate.Text = employee.hireDate.ToShortDateString();
                lblEndDate.Text = employee.endDate.ToShortDateString();
            }
            else
            {
                Session["Employee"] = null;
                Response.Redirect("/Admin/UpdateEmployee.aspx");
            }
        }

        protected void btnChange_Click(object sender, EventArgs e)
        {
            Response.Redirect("/Admin/UpdateEmployeeInfo.aspx");
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            EmployeeTier tier = new EmployeeTier();
            Employee employee = (Employee)Session["Employee"];

            tier.updateEmployee(employee);

            Session["Employee"] = null;
            Response.Redirect("/Admin/ViewAllEmployees.aspx");

        }
    }
}