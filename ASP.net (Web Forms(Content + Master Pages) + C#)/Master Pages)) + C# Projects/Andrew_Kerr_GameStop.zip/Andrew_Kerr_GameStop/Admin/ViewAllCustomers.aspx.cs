﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Andrew_Kerr_GameStop.Admin
{
    public partial class ViewAllCustomers : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            CustomerTier tier = new CustomerTier();
            List<Customer> customerList = new List<Customer>();
            customerList = tier.getAllCustomers();

            grdCustomers.DataSource = customerList;

            grdCustomers.DataBind();

        }

        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            Response.Redirect("/Admin/UpdateCustomer.aspx");
        }

        protected void btnDelete_Click(object sender, EventArgs e)
        {
            Response.Redirect("/Admin/DeleteCustomer.aspx");
        }
    }
}