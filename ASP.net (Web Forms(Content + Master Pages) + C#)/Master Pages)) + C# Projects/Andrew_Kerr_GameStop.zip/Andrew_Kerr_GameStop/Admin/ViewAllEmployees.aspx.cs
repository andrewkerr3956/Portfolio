﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Andrew_Kerr_GameStop.Admin
{
    public partial class ViewAllEmployees : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            List<Employee> employeeList = new List<Employee>();
            EmployeeTier tier = new EmployeeTier();

            employeeList = tier.getAllEmployees();

            grdEmployees.DataSource = employeeList;
            grdEmployees.DataBind();

        }

        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            Response.Redirect("/Admin/UpdateEmployee.aspx");
        }

        protected void btnDelete_Click(object sender, EventArgs e)
        {
            Response.Redirect("/Admin/DeleteEmployee.aspx");
        }
    }
}