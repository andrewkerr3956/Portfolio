﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Andrew_Kerr_GameStop.Admin
{
    public partial class ViewAllVideoGames : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            VideoGameTier tier = new VideoGameTier();
            List<VideoGame> gameList = new List<VideoGame>();
            gameList = tier.getAllVideoGames();

            grdVideoGames.DataSource = gameList;
            grdVideoGames.DataBind();

        }

        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            Response.Redirect("/Admin/UpdateVideoGame.aspx");
        }

        protected void btnDelete_Click(object sender, EventArgs e)
        {
            Response.Redirect("/Admin/DeleteVideoGame.aspx");
        }
    }
}