﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Andrew_Kerr_GameStop
{
    public partial class CustomerRegistrationConf : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["Customer"] == null )
            {
                Response.Redirect("/CustomerRegistration.aspx");
            }
            else
            {
                Customer customer = (Customer)Session["Customer"];
                lblFirstName.Text = customer.firstName;
                lblMiddleName.Text = customer.middleName;
                lblLastName.Text = customer.lastName;
                lblAddress.Text = customer.address;
                lblAddress2.Text = customer.address2;
                lblCity.Text = customer.city;
                lblState.Text = customer.state;
                lblZip.Text = customer.zip.ToString();
            }
        }

        protected void btnChange_Click(object sender, EventArgs e)
        {
            Customer customer = new Customer();
            customer.firstName = lblFirstName.Text;
            customer.middleName = lblMiddleName.Text;
            customer.lastName = lblLastName.Text;
            customer.address = lblAddress.Text;
            customer.address2 = lblAddress2.Text;
            customer.city = lblCity.Text;
            customer.state = lblState.Text;
            customer.zip = int.Parse(lblZip.Text);

            Session["Customer"] = customer;
            Response.Redirect("/CustomerRegistration.aspx");
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            CustomerTier tier = new CustomerTier();
            Customer customer = (Customer)Session["Customer"];

            tier.insertCustomer(customer);

            Response.Redirect("/Default.aspx");

        }
    }
}