﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data.SqlTypes;

namespace Andrew_Kerr_GameStop
{
    public class ConsoleTier : BaseTier
    {

        public ConsoleTier() : base()
        {

        }

        // Select methods
        public List<Console> getAllConsoles()
        {
            ConsoleTier tier;
            List<Console> consoleList = null;
            Console console;
            query = "SELECT * FROM Console;";
            conn = new SqlConnection(connectionString);
            cmd = new SqlCommand(query, conn);

            try
            {
                conn.Open();
                reader = cmd.ExecuteReader();
                if(reader.HasRows)
                {
                    consoleList = new List<Console>();
                    tier = new ConsoleTier();
                    while (reader.Read())
                    {
                        console = new Console();
                        console.consoleID = (int)reader["ConsoleID"];
                        console.consoleName = (string)reader["ConsoleName"];
                        if (reader["ConsoleDesc"] != DBNull.Value)
                        {
                            console.consoleDesc = (string)reader["ConsoleDesc"];
                        }
                        else
                        {
                            console.consoleDesc = "N/A";
                        }
                         console.manufacturer = (string)reader["Manufacturer"];
                         console.stockRemaining = (int)reader["StockRemaining"];
                        console.consoleCost = (decimal)reader["ConsoleCost"];

                        consoleList.Add(console);
                    }
                }
            }
            catch(SqlException ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                conn.Close();
            }


            return consoleList;
        }

        public Console getConsolebyId(int consoleID)
        {
            Console console;
            query = "SELECT * FROM Console WHERE ConsoleID = @ConsoleID;";
            conn = new SqlConnection(connectionString);
            cmd = new SqlCommand(query, conn);

            cmd.Parameters.Add("@ConsoleID", SqlDbType.Int).Value = consoleID;
            try
            {
                conn.Open();
                reader = cmd.ExecuteReader();
                if (reader.HasRows)
                {
                    console = new Console();
                    while (reader.Read())
                    {
                        console.consoleID = (int)reader["ConsoleID"];
                        console.consoleName = (string)reader["ConsoleName"];
                        if (reader["ConsoleDesc"] != DBNull.Value)
                        {
                            console.consoleDesc = (string)reader["ConsoleDesc"];
                        }
                        else
                        {
                            console.consoleDesc = "N/A";
                        }
                        console.manufacturer = (string)reader["Manufacturer"];
                        console.stockRemaining = (int)reader["StockRemaining"];
                        console.consoleCost = (decimal)reader["ConsoleCost"];
                    }
                }
                else
                {
                    console = null;
                }
            }
            catch (SqlException ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                conn.Close();
            }

            return console;
        }

        public byte[] getConsoleImage(int consoleID)
        {
            byte[] theImage = null;
            query = "SELECT ConsoleImage FROM Console WHERE ConsoleID = @ConsoleID;";
            conn = new SqlConnection(connectionString);
            cmd = new SqlCommand(query, conn);

            cmd.Parameters.Add("@ConsoleID", SqlDbType.Int).Value = consoleID;

            try
            {
                conn.Open();
                var data = cmd.ExecuteScalar();
                if ( data != DBNull.Value )
                {
                    theImage = (byte[])data;
                }
                else
                {
                    theImage = null;
                }
            }
            catch (SqlException ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                conn.Close();
            }

            return theImage;
        }


        // Insert methods
        public bool insertConsole(Console console)
        {
            query = "INSERT INTO Console " +
                    "(ConsoleName, ConsoleDesc, Manufacturer, StockRemaining, ConsoleCost, ConsoleImage) " +
                    "VALUES (@ConsoleName, @ConsoleDesc, @Manufacturer, @StockRemaining, @ConsoleCost, @ConsoleImage);";
            conn = new SqlConnection(connectionString);
            cmd = new SqlCommand(query, conn);
            int rows = 0;

            cmd.Parameters.Add("@ConsoleName", SqlDbType.NVarChar, 50).Value = console.consoleName;
            cmd.Parameters.Add("@ConsoleDesc", SqlDbType.NVarChar, 100).Value = console.consoleDesc;
            cmd.Parameters.Add("@Manufacturer", SqlDbType.NVarChar, 50).Value = console.manufacturer;
            cmd.Parameters.Add("@StockRemaining", SqlDbType.Int).Value = console.stockRemaining;
            cmd.Parameters.Add("@ConsoleCost", SqlDbType.Money).Value = console.consoleCost;
            cmd.Parameters.Add("@ConsoleImage", SqlDbType.Image).Value = console.consoleImage;

            try
            {
                conn.Open();
                rows = cmd.ExecuteNonQuery();
                if (rows > 0)
                {
                    success = true;
                }
                else
                {
                    success = false;
                }

            }
            catch (SqlException ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                conn.Close();
            }

            return success;
        }



        // Update methods
        public bool updateConsole(Console console)
        {
            query = "UPDATE Console " +
                    "SET ConsoleName = @ConsoleName, ConsoleDesc = @ConsoleDesc, Manufacturer = @Manufacturer, StockRemaining = @StockRemaining, ConsoleCost = @ConsoleCost, ConsoleImage = @ConsoleImage " +
                    "WHERE ConsoleID = @ConsoleID;";
            conn = new SqlConnection(connectionString);
            cmd = new SqlCommand(query, conn);
            int rows = 0;

            cmd.Parameters.Add("@ConsoleID", SqlDbType.Int).Value = console.consoleID;
            cmd.Parameters.Add("@ConsoleName", SqlDbType.NVarChar, 50).Value = console.consoleName;
            cmd.Parameters.Add("@ConsoleDesc", SqlDbType.NVarChar, 100).Value = console.consoleDesc;
            cmd.Parameters.Add("@Manufacturer", SqlDbType.NVarChar, 50).Value = console.manufacturer;
            cmd.Parameters.Add("@StockRemaining", SqlDbType.Int).Value = console.stockRemaining;
            cmd.Parameters.Add("@ConsoleCost", SqlDbType.Money).Value = console.consoleCost;
            cmd.Parameters.Add("@ConsoleImage", SqlDbType.Image).Value = console.consoleImage;

            try
            {
                conn.Open();
                rows = cmd.ExecuteNonQuery();
                if (rows > 0)
                {
                    success = true;
                }
                else
                {
                    success = false;
                }

            }
            catch (SqlException ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                conn.Close();
            }

            return success;
        }



        // Delete methods
        public bool deleteConsole(int consoleID)
        {
            query = "DELETE FROM Console WHERE ConsoleID = @ConsoleID;";
            conn = new SqlConnection(connectionString);
            cmd = new SqlCommand(query, conn);
            int rows = 0;

            cmd.Parameters.Add("@ConsoleID", SqlDbType.Int).Value = consoleID;

            try
            {
                conn.Open();
                rows = cmd.ExecuteNonQuery();
                if (rows > 0)
                {
                    success = true;
                }
                else
                {
                    success = false;
                }

            }
            catch (SqlException ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                conn.Close();
            }

            return success;
        }



    }
}