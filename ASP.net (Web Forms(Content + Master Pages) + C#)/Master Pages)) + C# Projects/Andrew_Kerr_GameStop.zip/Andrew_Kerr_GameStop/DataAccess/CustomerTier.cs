﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.Sql;
using System.Data.SqlTypes;
using System.Data.SqlClient;
using System.Configuration;

namespace Andrew_Kerr_GameStop
{
    public class CustomerTier : BaseTier
    {

        public CustomerTier() : base()
        {
        }

        // All Select Methods
        public List<Customer> getAllCustomers()
        {
            List<Customer> customerList = null;
            Customer customer;

            query = "SELECT * FROM Customer;";
            conn = new SqlConnection(connectionString);
            cmd = new SqlCommand(query, conn);

            try
            {
                conn.Open();
                reader = cmd.ExecuteReader();
                if (reader.HasRows)
                {
                    customerList = new List<Customer>();
                    while (reader.Read())
                    {
                        customer = new Customer();
                        customer.custID = (int)reader["CustID"];
                        customer.firstName = (string)reader["FirstName"];
                        if (reader["MiddleName"] != DBNull.Value)
                        {
                            customer.middleName = (string)reader["MiddleName"];
                        }
                        else
                        {
                            customer.middleName = "N/A";
                        }
                        customer.lastName = (string)reader["LastName"];
                        customer.address = (string)reader["Address"];
                        if (reader["Address2"] != DBNull.Value)
                        {
                            customer.address2 = (string)reader["Address2"];
                        }
                        customer.city = (string)reader["City"];
                        if (reader["State"] != DBNull.Value)
                        {
                            customer.state = (string)reader["State"];
                        }
                        else
                        {
                            customer.state = "N/A";
                        }
                        customer.zip = (int)reader["Zip"];

                        customerList.Add(customer);
                    }

                }
            }
            catch (SqlException ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                conn.Close();
            }

            return customerList;
        }

        public Customer getCustomerbyId(int custID)
        {
            query = "SELECT * FROM Customer " +
                    "WHERE CustID = @CustID;";
            conn = new SqlConnection(connectionString);
            cmd = new SqlCommand(query, conn);
            Customer customer;

            cmd.Parameters.Add("@CustID", SqlDbType.Int).Value = custID;

            try
            {
                conn.Open();
                reader = cmd.ExecuteReader();

                if (reader.HasRows)
                {
                    customer = new Customer();
                    while (reader.Read())
                    {

                        customer.custID = (int)reader["CustID"];
                        customer.firstName = (string)reader["FirstName"];
                        if (reader["MiddleName"] != DBNull.Value)
                        {
                            customer.middleName = (string)reader["MiddleName"];
                        }
                        else
                        {
                            customer.middleName = "N/A";
                        }
                        customer.lastName = (string)reader["LastName"];
                        customer.address = (string)reader["Address"];
                        if (reader["Address2"] != DBNull.Value)
                        {
                            customer.address2 = (string)reader["Address2"];
                        }
                        customer.city = (string)reader["City"];
                        if (reader["State"] != DBNull.Value)
                        {
                            customer.state = (string)reader["State"];
                        }
                        else
                        {
                            customer.state = "N/A";
                        }
                        customer.zip = (int)reader["Zip"];

                    }

                }
                else
                {
                    customer = null;
                }
            }
            catch (SqlException ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                conn.Close();
            }

            return customer;
        }

        // All Insert Methods
        public bool insertCustomer(Customer customer)
        {
            query = "INSERT INTO Customer " +
                    "(FirstName, MiddleName, LastName, Address, Address2, City, State, Zip) " +
                    "VALUES(@FirstName, @MiddleName, @LastName, @Address, @Address2, @City, @State, @Zip);";
            conn = new SqlConnection(connectionString);
            cmd = new SqlCommand(query, conn);
            int rows = 0;

            cmd.Parameters.Add("@FirstName", SqlDbType.NVarChar, 50).Value = customer.firstName;
            cmd.Parameters.Add("@MiddleName", SqlDbType.NVarChar, 50).Value = customer.middleName;
            cmd.Parameters.Add("@LastName", SqlDbType.NVarChar, 50).Value = customer.lastName;
            cmd.Parameters.Add("@Address", SqlDbType.NVarChar, 50).Value = customer.address;
            cmd.Parameters.Add("@Address2", SqlDbType.NVarChar, 50).Value = customer.address2;
            cmd.Parameters.Add("@City", SqlDbType.NVarChar, 50).Value = customer.city;
            cmd.Parameters.Add("@State", SqlDbType.NVarChar, 2).Value = customer.state;
            cmd.Parameters.Add("@Zip", SqlDbType.Int).Value = customer.zip;
            try
            {
                conn.Open();
                rows = cmd.ExecuteNonQuery();
                if (rows > 0)
                {
                    success = true;
                }
                else
                {
                    success = false;
                }

            }
            catch (SqlException ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                conn.Close();

            }

            return success;

        }

        // All Update Methods
        public bool updateCustomer(Customer customer)
        {
            query = "UPDATE Customer " +
                    "SET FirstName = @FirstName, MiddleName = @MiddleName, LastName = @LastName, Address = @Address, Address2 = @Address2, City = @City, Zip = @Zip " +
                    "WHERE CustID = @CustID;";
            conn = new SqlConnection(connectionString);
            cmd = new SqlCommand(query, conn);
            int rows = 0;

            cmd.Parameters.Add("@CustID", SqlDbType.Int).Value = customer.custID;
            cmd.Parameters.Add("@FirstName", SqlDbType.NVarChar, 50).Value = customer.firstName;
            cmd.Parameters.Add("@MiddleName", SqlDbType.NVarChar, 50).Value = customer.middleName;
            cmd.Parameters.Add("@LastName", SqlDbType.NVarChar, 50).Value = customer.lastName;
            cmd.Parameters.Add("@Address", SqlDbType.NVarChar, 50).Value = customer.address;
            cmd.Parameters.Add("@Address2", SqlDbType.NVarChar, 50).Value = customer.address2;
            cmd.Parameters.Add("@City", SqlDbType.NVarChar, 50).Value = customer.city;
            cmd.Parameters.Add("@State", SqlDbType.NVarChar, 2).Value = customer.state;
            cmd.Parameters.Add("@Zip", SqlDbType.Int).Value = customer.zip;

            try
            {
                conn.Open();
                rows = cmd.ExecuteNonQuery();
                if (rows > 0)
                {
                    success = true;
                }
                else
                {
                    success = false;
                }
            }
            catch (SqlException ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                conn.Close();
            }

            return success;
        }

        // All Delete Methods
        public bool deleteCustomer(int custID)
        {
            query = "DELETE FROM Customer WHERE CustID = @CustID;";
            conn = new SqlConnection(connectionString);
            cmd = new SqlCommand(query, conn);
            int rows = 0;

            cmd.Parameters.Add("@CustID", SqlDbType.Int).Value = custID;

            try
            {
                conn.Open();
                rows = cmd.ExecuteNonQuery();
                if (rows > 0)
                {
                    success = true;
                }
                else
                {
                    success = false;
                }
            }
            catch (SqlException ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                conn.Close();
            }

            return success;
        }


    }
}
