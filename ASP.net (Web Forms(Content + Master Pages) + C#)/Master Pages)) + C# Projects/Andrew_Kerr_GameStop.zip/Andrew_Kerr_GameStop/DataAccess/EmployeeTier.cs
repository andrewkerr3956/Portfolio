﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data.SqlTypes;


namespace Andrew_Kerr_GameStop
{
    public class EmployeeTier : BaseTier
    {

        public EmployeeTier() : base()
        {

        }

        // Select methods
        public List<Employee> getAllEmployees()
        {
            Employee employee;
            List<Employee> employeeList = null;
            query = "SELECT * FROM Employee;";
            conn = new SqlConnection(connectionString);
            cmd = new SqlCommand(query, conn);

            try
            {
                conn.Open();
                reader = cmd.ExecuteReader();
                if (reader.HasRows)
                {
                    employeeList = new List<Employee>();
                    while (reader.Read())
                    {
                        employee = new Employee();
                        employee.empID = (int)reader["EmpID"];
                        employee.firstName = (string)reader["FirstName"];
                        if( reader["MiddleName"] != DBNull.Value )
                        {
                            employee.middleName = (string)reader["MiddleName"];
                        }
                        else
                        {
                            employee.middleName = "N/A";
                        }
                        employee.lastName = (string)reader["LastName"];
                        employee.address = (string)reader["Address"];
                        if( reader["Address2"] != DBNull.Value )
                        {
                            employee.address2 = (string)reader["Address2"];
                        }    
                        else
                        {
                            employee.address2 = "N/A";
                        }
                        employee.city = (string)reader["City"];
                        if( reader["State"] != DBNull.Value )
                        {
                            employee.state = (string)reader["State"];
                        }
                        else
                        {
                            employee.state = "N/A";
                        }
                        employee.zip = (int)reader["Zip"];
                        employee.hireDate = (DateTime)reader["HireDate"];
                        if ( reader["EndDate"] != DBNull.Value )
                        {
                            employee.endDate = (DateTime)reader["EndDate"];
                        }
                        else
                        {
                            employee.endDate = DateTime.Parse("N/A");
                        }
                        employee.location = (string)reader["Location"];

                        employeeList.Add(employee);
                    }
                }
            }
            catch (SqlException ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                conn.Close();
            }

            return employeeList;
        }

        public Employee getEmployeebyId(int empID)
        {
            Employee employee;
            query = "SELECT * FROM Employee WHERE EmpID = @EmpID;";
            conn = new SqlConnection(connectionString);
            cmd = new SqlCommand(query, conn);

            cmd.Parameters.Add("@EmpID", SqlDbType.Int).Value = empID;
            try
            {
                conn.Open();
                reader = cmd.ExecuteReader();
                if (reader.HasRows)
                {
                    employee = new Employee();
                    while (reader.Read())
                    {
                        employee.empID = (int)reader["EmpID"];
                        employee.firstName = (string)reader["FirstName"];
                        if (reader["MiddleName"] != DBNull.Value)
                        {
                            employee.middleName = (string)reader["MiddleName"];
                        }
                        else
                        {
                            employee.middleName = "N/A";
                        }
                        employee.lastName = (string)reader["LastName"];
                        employee.address = (string)reader["Address"];
                        if (reader["Address2"] != DBNull.Value)
                        {
                            employee.address2 = (string)reader["Address2"];
                        }
                        else
                        {
                            employee.address2 = "N/A";
                        }
                        employee.city = (string)reader["City"];
                        if (reader["State"] != DBNull.Value)
                        {
                            employee.state = (string)reader["State"];
                        }
                        else
                        {
                            employee.state = "N/A";
                        }
                        employee.zip = (int)reader["Zip"];
                        employee.hireDate = (DateTime)reader["HireDate"];
                        if (reader["EndDate"] != DBNull.Value)
                        {
                            employee.endDate = (DateTime)reader["EndDate"];
                        }
                        employee.location = (string)reader["Location"];
                    }
                }
                else
                {
                    employee = null;
                }
            }
            catch(SqlException ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                conn.Close();
            }

            return employee;
        }

        // Insert Methods
        public bool insertEmployee (Employee employee)
        {
            query = "INSERT INTO Employee (FirstName, MiddleName, LastName, Address, Address2, City, State, Zip, HireDate, EndDate, Location) " +
                    "VALUES (@FirstName, @MiddleName, @LastName, @Address, @Address2, @City, @State, @Zip, @HireDate, @EndDate, @Location);";
            conn = new SqlConnection(connectionString);
            cmd = new SqlCommand(query, conn);
            int rows = 0;

            cmd.Parameters.Add("@FirstName", SqlDbType.NVarChar, 50).Value = employee.firstName;
            cmd.Parameters.Add("@MiddleName", SqlDbType.NVarChar, 50).Value = employee.middleName;
            cmd.Parameters.Add("@LastName", SqlDbType.NVarChar, 50).Value = employee.lastName;
            cmd.Parameters.Add("@Address", SqlDbType.NVarChar, 50).Value = employee.address;
            cmd.Parameters.Add("@Address2", SqlDbType.NVarChar, 50).Value = employee.address2;
            cmd.Parameters.Add("@City", SqlDbType.NVarChar, 50).Value = employee.city;
            cmd.Parameters.Add("@State", SqlDbType.NVarChar, 2).Value = employee.state;
            cmd.Parameters.Add("@Zip", SqlDbType.Int).Value = employee.zip;
            cmd.Parameters.Add("@HireDate", SqlDbType.Date).Value = employee.hireDate;
            cmd.Parameters.Add("@EndDate", SqlDbType.Date).Value = employee.endDate;
            cmd.Parameters.Add("@Location", SqlDbType.NVarChar, 50).Value = employee.location;

            try
            {
                conn.Open();
                rows = cmd.ExecuteNonQuery();
                if (rows > 0)
                {
                    success = true;
                }
                else
                {
                    success = false;
                }

            }
            catch (SqlException ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                conn.Close();
            }

            return success;
        }

        // Update methods
        public bool updateEmployee(Employee employee)
        {
            query = "UPDATE Employee " +
                    "SET FirstName = @FirstName, MiddleName = @MiddleName, LastName = @LastName, Address = @Address, Address2 = @Address2, City = @City, State = @State, Zip = @Zip, " +
                    "HireDate = @HireDate, EndDate = @EndDate, Location = @Location " +
                    "WHERE EmpID = @EmpID;";
            conn = new SqlConnection(connectionString);
            cmd = new SqlCommand(query, conn);
            int rows = 0;

            cmd.Parameters.Add("@EmpID", SqlDbType.Int).Value = employee.empID;
            cmd.Parameters.Add("@FirstName", SqlDbType.NVarChar, 50).Value = employee.firstName;
            cmd.Parameters.Add("@MiddleName", SqlDbType.NVarChar, 50).Value = employee.middleName;
            cmd.Parameters.Add("@LastName", SqlDbType.NVarChar, 50).Value = employee.lastName;
            cmd.Parameters.Add("@Address", SqlDbType.NVarChar, 50).Value = employee.address;
            cmd.Parameters.Add("@Address2", SqlDbType.NVarChar, 50).Value = employee.address2;
            cmd.Parameters.Add("@City", SqlDbType.NVarChar, 50).Value = employee.city;
            cmd.Parameters.Add("@State", SqlDbType.NVarChar, 2).Value = employee.state;
            cmd.Parameters.Add("@Zip", SqlDbType.Int).Value = employee.zip;
            cmd.Parameters.Add("@HireDate", SqlDbType.Date).Value = employee.hireDate;
            cmd.Parameters.Add("@EndDate", SqlDbType.Date).Value = employee.endDate;
            cmd.Parameters.Add("@Location", SqlDbType.NVarChar, 50).Value = employee.location;

            try
            {
                conn.Open();
                rows = cmd.ExecuteNonQuery();
                if (rows > 0)
                {
                    success = true;
                }
                else
                {
                    success = false;
                }

            }
            catch (SqlException ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                conn.Close();
            }

            return success;
        }

        // Delete methods
        public bool deleteEmployee(int empID)
        {
            query = "DELETE FROM Employee WHERE EmpID = @EmpID;";
            conn = new SqlConnection(connectionString);
            cmd = new SqlCommand(query, conn);
            int rows = 0;

            cmd.Parameters.Add("@EmpID", SqlDbType.Int).Value = empID;
            try
            {
                conn.Open();
                rows = cmd.ExecuteNonQuery();
                if (rows > 0)
                {
                    success = true;
                }
                else
                {
                    success = false;
                }

            }
            catch (SqlException ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                conn.Close();
            }

            return success;
        }


    }
}