﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data.SqlTypes;

namespace Andrew_Kerr_GameStop
{
    public class VideoGameTier : BaseTier
    {
        public VideoGameTier() : base()
        {
        }
        // Select Methods
        public List<VideoGame> getAllVideoGames()
        {
            query = "SELECT * FROM VideoGame;";
            conn = new SqlConnection(connectionString);
            cmd = new SqlCommand(query, conn);
            List<VideoGame> gameList = null;
            VideoGame game;

            try
            {
                conn.Open();
                reader = cmd.ExecuteReader();
                if (reader.HasRows)
                {
                    gameList = new List<VideoGame>();
                    while (reader.Read())
                    {
                        game = new VideoGame();
                        game.gameID = (int)reader["GameID"];
                        game.gameTitle = (string)reader["GameTitle"];
                        if (reader["GameDesc"] != DBNull.Value)
                        {
                            game.gameDesc = (string)reader["GameDesc"];
                        }
                        else
                        {
                            game.gameDesc = "N/A";
                        }
                        game.developer = (string)reader["Developer"];
                        if (reader["Genre"] != DBNull.Value)
                        {
                            game.genre = (string)reader["Genre"];
                        }
                        else
                        {
                            game.genre = "N/A";
                        }
                        game.stockRemaining = (int)reader["StockRemaining"];
                        game.gameCost = (decimal)reader["GameCost"];
                        if (reader["GameImage"] != DBNull.Value)
                        {
                            game.gameImage = (byte[])reader["GameImage"];
                        }
                        else
                        {
                            game.gameImage = null;
                        }
                        if (reader["ConsoleID"] != DBNull.Value)
                        {
                            game.consoleID = (int)reader["ConsoleID"];
                        }
                        else
                        {
                            game.consoleID = 1;
                        }

                        gameList.Add(game);
                    }
                }
            }
            catch (SqlException ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                conn.Close();
            }

            return gameList;
        }

        public VideoGame getVideoGamebyId(int gameID)
        {
            VideoGame game;
            query = "SELECT * FROM VideoGame WHERE GameID = @GameID;";
            conn = new SqlConnection(connectionString);
            cmd = new SqlCommand(query, conn);

            cmd.Parameters.Add("@GameID", SqlDbType.Int).Value = gameID;
            try
            {
                conn.Open();
                reader = cmd.ExecuteReader();
                if (reader.HasRows)
                {
                    game = new VideoGame();
                    while (reader.Read())
                    {
                        game.gameID = (int)reader["GameID"];
                        game.gameTitle = (string)reader["GameTitle"];
                        if (reader["GameDesc"] != DBNull.Value)
                        {
                            game.gameDesc = (string)reader["GameDesc"];
                        }
                        else
                        {
                            game.gameDesc = "N/A";
                        }
                        game.developer = (string)reader["Developer"];
                        if (reader["Genre"] != DBNull.Value)
                        {
                            game.genre = (string)reader["Genre"];
                        }
                        else
                        {
                            game.genre = "N/A";
                        }
                        game.stockRemaining = (int)reader["StockRemaining"];
                        game.gameCost = (decimal)reader["GameCost"];
                        if (reader["ConsoleID"] != DBNull.Value)
                        {
                            game.consoleID = (int)reader["ConsoleID"];
                        }
                        else
                        {
                            game.consoleID = 1;
                        }
                    }
                }
                else
                {
                    game = null;
                }
            }
            catch (SqlException ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                conn.Close();
            }

            return game;
        }

        // Obtain the console information if needed
        public Console getConsolebyName(string consoleName)
        {
            // This will check if the console name specified is in the consoles database.
            query = "SELECT * FROM Console WHERE ConsoleName = @ConsoleName;";
            conn = new SqlConnection(connectionString);
            cmd = new SqlCommand(query, conn);
            Console console = new Console();

            cmd.Parameters.Add("@ConsoleName", SqlDbType.NVarChar, 50).Value = consoleName;

            try
            {
                conn.Open();
                reader = cmd.ExecuteReader();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        console = new Console();
                        console.consoleID = (int)reader["ConsoleID"];
                        console.consoleName = (string)reader["ConsoleName"];
                        if (reader["ConsoleDesc"] != DBNull.Value)
                        {
                            console.consoleDesc = (string)reader["ConsoleDesc"];
                        }
                        else
                        {
                            console.consoleDesc = "N/A";
                        }
                        console.manufacturer = (string)reader["Manufacturer"];
                        console.stockRemaining = (int)reader["StockRemaining"];
                        console.consoleCost = (decimal)reader["ConsoleCost"];
                    }
                }
                else
                {
                    console = null;
                }
                
            }
            catch(SqlException ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                conn.Close();
            }

            return console;
        }

        public Console getConsolebyId(int consoleID)
        {
            Console console;
            query = "SELECT * FROM Console WHERE ConsoleID = @ConsoleID;";
            conn = new SqlConnection(connectionString);
            cmd = new SqlCommand(query, conn);

            cmd.Parameters.Add("@ConsoleID", SqlDbType.Int).Value = consoleID;
            try
            {
                conn.Open();
                reader = cmd.ExecuteReader();
                if (reader.HasRows)
                {
                    console = new Console();
                    while (reader.Read())
                    {
                        console.consoleID = (int)reader["ConsoleID"];
                        console.consoleName = (string)reader["ConsoleName"];
                        if (reader["ConsoleDesc"] != DBNull.Value)
                        {
                            console.consoleDesc = (string)reader["ConsoleDesc"];
                        }
                        else
                        {
                            console.consoleDesc = "N/A";
                        }
                        console.manufacturer = (string)reader["Manufacturer"];
                        console.stockRemaining = (int)reader["StockRemaining"];
                        console.consoleCost = (decimal)reader["ConsoleCost"];
                    }
                }
                else
                {
                    console = null;
                }
            }
            catch (SqlException ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                conn.Close();
            }

            return console;
        }

        // Video Game Image
        public byte[] getVideoGameImage(int gameID)
        {
            byte[] gameImage = null;
            query = "SELECT GameImage FROM VideoGame WHERE GameID = @GameID;";
            conn = new SqlConnection(connectionString);
            cmd = new SqlCommand(query, conn);

            cmd.Parameters.Add("@GameID", SqlDbType.Int).Value = gameID;

            try
            {
                conn.Open();
                var gameData = cmd.ExecuteScalar();
                if (gameData != DBNull.Value)
                {
                    gameImage = (byte[])gameData;
                }
                else
                {
                    gameImage = null;
                }
            }
            catch (SqlException ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                conn.Close();
            }

            return gameImage;
        }


        // Insert Methods
        public bool insertVideoGame(VideoGame game)
        {
            query = "INSERT INTO VideoGame (GameTitle, GameDesc, Developer, Genre, StockRemaining, GameCost, GameImage, ConsoleID) " +
                "VALUES (@GameTitle, @GameDesc, @Developer, @Genre, @StockRemaining, @GameCost, @GameImage, @ConsoleID);";
            conn = new SqlConnection(connectionString);
            cmd = new SqlCommand(query, conn);
            int rows = 0;

            cmd.Parameters.Add("@GameTitle", SqlDbType.NVarChar, 50).Value = game.gameTitle;
            cmd.Parameters.Add("@GameDesc", SqlDbType.NVarChar, 100).Value = game.gameDesc;
            cmd.Parameters.Add("@Developer", SqlDbType.NVarChar, 50).Value = game.developer;
            cmd.Parameters.Add("@Genre", SqlDbType.NVarChar, 50).Value = game.genre;
            cmd.Parameters.Add("@StockRemaining", SqlDbType.Int).Value = game.stockRemaining;
            cmd.Parameters.Add("@GameCost", SqlDbType.Money).Value = game.gameCost;
            cmd.Parameters.Add("@GameImage", SqlDbType.Image).Value = game.gameImage;
            cmd.Parameters.Add("@ConsoleID", SqlDbType.Int).Value = game.consoleID;

            try
            {
                conn.Open();
                rows = cmd.ExecuteNonQuery();
                if (rows > 0)
                {
                    success = true;
                }
                else
                {
                    success = false;
                }

            }
            catch (SqlException ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                conn.Close();
            }

            return success;
        }


        // Update Methods
        public bool updateVideoGame(VideoGame game)
        {
            query = "UPDATE VideoGame " +
                    "SET GameTitle = @GameTitle, GameDesc = @GameDesc, Developer = @Developer, Genre = @Genre, StockRemaining = @StockRemaining, GameCost = @GameCost, " +
                    "GameImage = @GameImage, ConsoleID = @ConsoleID " +
                    "WHERE GameID = @GameID;";
            conn = new SqlConnection(connectionString);
            cmd = new SqlCommand(query, conn);
            int rows = 0;

            cmd.Parameters.Add("@GameID", SqlDbType.Int).Value = game.gameID;
            cmd.Parameters.Add("@GameTitle", SqlDbType.NVarChar, 50).Value = game.gameTitle;
            cmd.Parameters.Add("@GameDesc", SqlDbType.NVarChar, 100).Value = game.gameDesc;
            cmd.Parameters.Add("@Developer", SqlDbType.NVarChar, 50).Value = game.developer;
            cmd.Parameters.Add("@Genre", SqlDbType.NVarChar, 50).Value = game.genre;
            cmd.Parameters.Add("@StockRemaining", SqlDbType.Int).Value = game.stockRemaining;
            cmd.Parameters.Add("@GameCost", SqlDbType.Money).Value = game.gameCost;
            cmd.Parameters.Add("@GameImage", SqlDbType.Image).Value = game.gameImage;
            cmd.Parameters.Add("@ConsoleID", SqlDbType.Int).Value = game.consoleID;

            try
            {
                conn.Open();
                rows = cmd.ExecuteNonQuery();
                if(rows > 0)
                {
                    success = true;
                }
                else
                {
                    success = false;
                }
            }
            catch (SqlException ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                conn.Close();
            }

            return success;
        }


        // Delete Methods
        public bool deleteVideoGame(int gameID)
        {
            query = "DELETE FROM VideoGame WHERE GameID = @GameID;";
            conn = new SqlConnection(connectionString);
            cmd = new SqlCommand(query, conn);
            int rows = 0;

            cmd.Parameters.Add("@GameID", SqlDbType.Int).Value = gameID;

            try
            {
                conn.Open();
                rows = cmd.ExecuteNonQuery();
                if (rows > 0)
                {
                    success = true;
                }
                else
                {
                    success = false;
                }
            }
            catch (SqlException ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                conn.Close();
            }

            return success;
        }




    }
}