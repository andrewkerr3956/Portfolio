﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Andrew_Kerr_GameStop.Handlers
{
    /// <summary>
    /// Summary description for consoleImage
    /// </summary>
    public class consoleImage : IHttpHandler
    {
        public void ProcessRequest(HttpContext context)
        {
            string urlCheck = context.Request.Url.ToString();
            if (urlCheck.Contains("/Handlers/consoleImage.ashx?ID="))
            {
                byte[] theImage;
                ConsoleTier theTier = new ConsoleTier();
                //Using the information from the URL, get the console ID
                Int32 imageID = Int32.Parse(context.Request.QueryString["ID"]);

                //Using the productID, get the image of the console from the data tier
                theImage = theTier.getConsoleImage(imageID);

                //Send the binary data to the URL requesting it.
                if (theImage != null)
                {
                    context.Response.BinaryWrite(theImage);
                }
                

            }
            else
            {
                byte[] theImage;
                VideoGameTier theTier = new VideoGameTier();
                //Using the information from the URL, get the console ID
                Int32 imageID = Int32.Parse(context.Request.QueryString["ID"]);

                //Using the productID, get the image of the console from the data tier
                theImage = theTier.getVideoGameImage(imageID);

                //Send the binary data to the URL requesting it.
                if (theImage != null)
                {
                    context.Response.BinaryWrite(theImage);
                }
            }

        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
    }

}