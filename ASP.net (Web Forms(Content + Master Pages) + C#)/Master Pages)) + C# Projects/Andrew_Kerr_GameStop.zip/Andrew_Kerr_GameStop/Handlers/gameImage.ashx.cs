﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Andrew_Kerr_GameStop.Handlers
{
    /// <summary>
    /// Summary description for gameImage
    /// </summary>
    public class gameImage : IHttpHandler
    {
        public void ProcessRequest(HttpContext context)
        {
            byte[] theImage;
            VideoGameTier theTier = new VideoGameTier();
            //Using the information from the URL, get the game ID
            Int32 imageID = Int32.Parse(context.Request.QueryString["ID"]);

            //Using the gameID, get the image of the console from the data tier
            theImage = theTier.getVideoGameImage(imageID);

            //Send the binary data to the URL requesting it.
            if (theImage != null)
            {
                context.Response.BinaryWrite(theImage);
            }

        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
    }

}