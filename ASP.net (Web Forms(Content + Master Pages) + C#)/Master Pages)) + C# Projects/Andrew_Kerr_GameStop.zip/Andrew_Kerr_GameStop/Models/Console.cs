﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Andrew_Kerr_GameStop
{
    public class Console
    {

        public int consoleID { get; set; }
        public string consoleName { get; set; }
        public string consoleDesc { get; set; }
        public string manufacturer { get; set; }
        public int stockRemaining { get; set; }
        public decimal consoleCost { get; set; }
        public byte[] consoleImage { get; set; }

    }
}