﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Andrew_Kerr_GameStop
{
    public class VideoGame
    {
        public int gameID { get; set; }
        public string gameTitle { get; set; }
        public string gameDesc { get; set; }
        public string developer { get; set; }
        public string genre { get; set; }
        public int stockRemaining { get; set; }
        public decimal gameCost { get; set; }
        public byte[] gameImage { get; set; }
        public int consoleID { get; set; }

    }
}