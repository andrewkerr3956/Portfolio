﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Andrew_Kerr_GameStop
{
    public partial class ShopConsoles : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Table listAllConsoles = null;
            ConsoleTier tier = new ConsoleTier();
            List<Console> consoleList = tier.getAllConsoles();
            listAllConsoles = new Table();
            TableRow tr = new TableRow();
            foreach (Console c in consoleList)
            {
                if (tr.Cells.Count == 3)
                {
                    tr = new TableRow();
                    TableCell td = new TableCell();
                    Table table = buildTable(c);
                    td.Controls.Add(table);
                    tr.Cells.Add(td);
                }
                else
                {
                    TableCell td = new TableCell();
                    Table table = buildTable(c);
                    td.Controls.Add(table);
                    tr.Cells.Add(td);
                }
                


                listAllConsoles.Rows.Add(tr);
            }

            pnlConsoles.Controls.Add(listAllConsoles);
        }

        private Table buildTable(Console console)
        {
            Table consoleTable = new Table();
            TableRow tr = new TableRow();

            TableCell td = new TableCell();
            Image consoleImage = new Image();
            Label consoleLabel = new Label();
            Button addToCart = new Button();

            // Name of the console
            consoleLabel.Text = console.consoleName;
            consoleLabel.Font.Bold = true;
            consoleLabel.Font.Size = 18;
            td.CssClass = "text-center";
            td.Controls.Add(consoleLabel);
            tr.Cells.Add(td);
            consoleTable.Rows.Add(tr);

            // Image of the console
            tr = new TableRow();
            td = new TableCell();
            consoleImage.ImageUrl = "/Handlers/consoleImage.ashx?ID=" + console.consoleID.ToString();
            consoleImage.CssClass = "img-thumbnail img-fluid";
            td.CssClass = "text-center";
            td.Controls.Add(consoleImage);
            tr.Cells.Add(td);
            consoleTable.Rows.Add(tr);

            // Manufacturer of the console
            consoleLabel = new Label();
            tr = new TableRow();
            td = new TableCell();
            
            consoleLabel.Text = "<strong>" + console.manufacturer + "</strong>";
            td.CssClass = "text-center";
            td.Controls.Add(consoleLabel);
            tr.Cells.Add(td);
            consoleTable.Rows.Add(tr);

            // Description of the console
            consoleLabel = new Label();
            tr = new TableRow();
            td = new TableCell();

            consoleLabel.Text = console.consoleDesc;
            consoleLabel.CssClass = "text-wrap";
            td.Controls.Add(consoleLabel);
            tr.Cells.Add(td);
            consoleTable.Rows.Add(tr);

            // Stock Remaining of the console
            consoleLabel = new Label();
            tr = new TableRow();
            td = new TableCell();

            consoleLabel.Text = "Stock Remaining: " + console.stockRemaining.ToString();
            td.CssClass = "text-center";
            td.Controls.Add(consoleLabel);
            tr.Controls.Add(td);
            consoleTable.Rows.Add(tr);

            // Price of the console
            consoleLabel = new Label();
            tr = new TableRow();
            td = new TableCell();

            consoleLabel.Text = "<strong>" + "Price: $" + Math.Round(console.consoleCost, 2).ToString() + "</strong>";
            td.CssClass = "text-center";
            td.Controls.Add(consoleLabel);
            tr.Cells.Add(td);
            consoleTable.Rows.Add(tr);

            // Add to cart button
            tr = new TableRow();
            td = new TableCell();

            td.CssClass = "text-center";
            addToCart.Text = "Add to Cart";
            addToCart.CssClass = "btn btn-success";
            addToCart.ID = console.consoleID.ToString();
            addToCart.Click += new EventHandler(btnAddToCart_Click);

            td.Controls.Add(addToCart);
            tr.Cells.Add(td);
            consoleTable.Rows.Add(tr);

            return consoleTable;
        }

        protected void btnAddToCart_Click(object sender, EventArgs e)
        {
            lblClicked.Text = "Added item to cart!";
        }
    }
}