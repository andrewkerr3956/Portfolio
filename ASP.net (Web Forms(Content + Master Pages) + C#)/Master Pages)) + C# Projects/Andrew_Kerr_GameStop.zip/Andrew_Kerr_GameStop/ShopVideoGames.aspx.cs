﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Andrew_Kerr_GameStop
{
    public partial class ShopVideoGames : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Table listAllGames = null;
            VideoGameTier tier = new VideoGameTier();
            List<VideoGame> gameList = tier.getAllVideoGames();
            listAllGames = new Table();
            TableRow tr = new TableRow();
            foreach (VideoGame v in gameList)
            {
                if (tr.Cells.Count == 3)
                {
                    tr = new TableRow();
                    TableCell td = new TableCell();
                    Table table = buildTable(v);
                    td.Controls.Add(table);
                    tr.Cells.Add(td);

                }
                else
                {
                    TableCell td = new TableCell();
                    Table table = buildTable(v);
                    td.Controls.Add(table);
                    tr.Cells.Add(td);
                }

                listAllGames.Rows.Add(tr);
            }

            pnlVideoGames.Controls.Add(listAllGames);
        }

        private Table buildTable(VideoGame game)
        {
            Table gameTable = new Table();
            TableRow tr = new TableRow();

            TableCell td = new TableCell();
            Label gameLabel = new Label();
            Image gameImage = new Image();
            Button addToCart = new Button();

            // Game Title
            gameLabel.Text = game.gameTitle;
            gameLabel.Font.Bold = true;
            gameLabel.Font.Size = 20;
            td.CssClass = "text-center";

            td.Controls.Add(gameLabel);
            tr.Cells.Add(td);
            gameTable.Rows.Add(tr);

            // Console Name
            VideoGameTier tier = new VideoGameTier(); 
            Console console = tier.getConsolebyId(game.consoleID);
            tr = new TableRow();
            td = new TableCell();
            gameLabel = new Label();
            gameLabel.Text = console.consoleName;
            td.CssClass = "text-center";

            td.Controls.Add(gameLabel);
            tr.Cells.Add(td);
            gameTable.Rows.Add(tr);

            // Game Image
            tr = new TableRow();
            td = new TableCell();
            gameImage.ImageUrl = "/Handlers/gameImage.ashx?ID=" + game.gameID.ToString();
            gameImage.CssClass = "img-thumbnail img-fluid";
            td.CssClass = "text-center";

            td.Controls.Add(gameImage);
            tr.Cells.Add(td);
            gameTable.Rows.Add(tr);

            // Game Description
            tr = new TableRow();
            td = new TableCell();
            gameLabel = new Label();
            gameLabel.Text = game.gameDesc;
            td.CssClass = "text-center";

            td.Controls.Add(gameLabel);
            tr.Cells.Add(td);
            gameTable.Rows.Add(tr);

            // Developer
            tr = new TableRow();
            td = new TableCell();
            gameLabel = new Label();
            gameLabel.Text = "<strong>Developer: " + game.developer + "</strong>";
            td.CssClass = "text-center";

            td.Controls.Add(gameLabel);
            tr.Cells.Add(td);
            gameTable.Rows.Add(tr);

            // Genre
            tr = new TableRow();
            td = new TableCell();
            gameLabel = new Label();
            gameLabel.Text = "<strong>Genre: " + game.genre + "</strong>";
            td.CssClass = "text-center";

            td.Controls.Add(gameLabel);
            tr.Cells.Add(td);
            gameTable.Rows.Add(tr);

            // Stock Remaining
            tr = new TableRow();
            td = new TableCell();
            gameLabel = new Label();
            gameLabel.Text = "Stock Remaining: " + game.stockRemaining.ToString();
            td.CssClass = "text-center";

            td.Controls.Add(gameLabel);
            tr.Cells.Add(td);
            gameTable.Rows.Add(tr);

            // Game Cost
            tr = new TableRow();
            td = new TableCell();
            gameLabel = new Label();
            gameLabel.Text = "<strong>Price: $" + Math.Round(game.gameCost, 2) + "</strong>";
            td.CssClass = "text-center";

            td.Controls.Add(gameLabel);
            tr.Cells.Add(td);
            gameTable.Rows.Add(tr);

            // Add to Cart Button
            tr = new TableRow();
            td = new TableCell();

            td.CssClass = "text-center";
            addToCart.Text = "Add to Cart";
            addToCart.CssClass = "btn btn-success";
            addToCart.ID = game.gameID.ToString();
            addToCart.Click += new EventHandler(btnAddToCart_Click);

            td.Controls.Add(addToCart);
            tr.Cells.Add(td);
            gameTable.Rows.Add(tr);

            return gameTable;

        }

        protected void btnAddToCart_Click(object sender, EventArgs e)
        {
            // Needs to be done
            lblClicked.Text = "Added item to cart!";
        }

    }
}