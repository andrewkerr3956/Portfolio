﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using HardwareStore_AndrewKerr.DataAccess;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data.SqlTypes;

namespace HardwareStore_AndrewKerr.Admin
{
    public partial class AddProducts : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            Product product = new Product();
            product.productName = txtProductName.Text;
            product.productDetails = txtProductDetails.Text;
            product.quantityOnHand = int.Parse(txtQuantityOnHand.Text);
            product.currentPrice = decimal.Parse(txtCurrentPrice.Text);
            
            // Image Saving

            // gets the full path of the file
            string filePath = flProduct.PostedFile.FileName;
            // extract from the filePath the name of the file
            string fileName = Path.GetFileName(filePath);
            // opening up a file stream and sending the image to the stream
            Stream fs = flProduct.PostedFile.InputStream;
           // setup a binary reader using the file stream
            BinaryReader br = new BinaryReader(fs);

            //read the bytes and puts data into theImage from the file stream
            byte[] theImage = br.ReadBytes((Int32)fs.Length);

            ProductTier theTier = new ProductTier();

            product.productImage = theImage;

            theTier.insertProduct(product);

            Response.Redirect("/Admin/ListAllProducts.aspx");

        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            txtProductName.Text = "";
            txtProductDetails.Text = "";
            txtQuantityOnHand.Text = "";
            txtCurrentPrice.Text = "";
            flProduct = null;
        }
    }
}