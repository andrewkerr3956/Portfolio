﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace HardwareStore_AndrewKerr.Admin
{
    public partial class EmployeeRegistration : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["Employee"] != null)
            {
                Employee employee = (Employee)Session["Employee"];

                txtFirstName.Text = employee.firstName;
                txtMiddleName.Text = employee.middleName;
                txtLastName.Text = employee.lastName;
                txtAddress.Text = employee.address;
                txtAddress2.Text = employee.address2;
                txtCity.Text = employee.city;
                txtState.Text = employee.state;
                txtZipCode.Text = employee.zipCode;
                txtTaxID.Text = employee.taxID;
                txtHireDate.Text = hireCalendar.SelectedDate.ToShortDateString();
                txtEndDate.Text = endCalendar.SelectedDate.ToShortDateString();
                txtManagerID.Text = employee.managerID.ToString();

                Session["Employee"] = null;

            }
            

        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            Employee employee = new Employee();

            employee.firstName = txtFirstName.Text;
            employee.middleName = txtMiddleName.Text;
            employee.lastName = txtLastName.Text;
            employee.address = txtAddress.Text;
            employee.address2 = txtAddress2.Text;
            employee.city = txtCity.Text;
            employee.state = txtState.Text;
            employee.zipCode = txtZipCode.Text;
            employee.taxID = txtTaxID.Text;
            employee.hireDate = hireCalendar.SelectedDate.Date;
            if (txtEndDate.Text != null)
            {
                employee.endDate = endCalendar.SelectedDate.Date;
            }
            else
            {
                employee.endDate = DateTime.Parse("N/A");
            }
            employee.managerID = int.Parse(txtManagerID.Text);

            Session["Employee"] = null;
            Session["Employee"] = employee;

            Response.Redirect("EmployeeRegistrationConf.aspx");
        }

        protected void btnClear_Click(object sender, EventArgs e)
        {
            txtFirstName.Text = "";
            txtMiddleName.Text = "";
            txtLastName.Text = "";
            txtAddress.Text = "";
            txtAddress2.Text = "";
            txtCity.Text = "";
            txtState.Text = "";
            txtZipCode.Text = "";
            txtTaxID.Text = "";
            txtHireDate.Text = "";
            txtEndDate.Text = "";
            txtManagerID.Text = "";

        }

        protected void btnHireDate_Click(object sender, EventArgs e)
        {
            hireCalendar.Visible = true;
        }

        protected void hireCalendar_SelectionChanged(object sender, EventArgs e)
        {
            txtHireDate.Text = hireCalendar.SelectedDate.ToShortDateString();
            hireCalendar.Visible = false;
        }

        protected void btnEndDate_Click(object sender, EventArgs e)
        {
            endCalendar.Visible = true;
        }
        protected void endCalendar_SelectionChanged(object sender, EventArgs e)
        {
            txtEndDate.Text = endCalendar.SelectedDate.ToShortDateString();
            endCalendar.Visible = false;
        }
    }
}