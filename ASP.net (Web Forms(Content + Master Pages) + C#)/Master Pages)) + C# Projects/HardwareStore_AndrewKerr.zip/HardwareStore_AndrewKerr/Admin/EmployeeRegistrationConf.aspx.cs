﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using HardwareStore_AndrewKerr.DataAccess;

namespace HardwareStore_AndrewKerr.Admin
{
    public partial class EmployeeRegistrationConf : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["Employee"] != null)
            {
                Employee employee = (Employee)Session["Employee"];
                lblFirstName.Text = employee.firstName;
                lblMiddleName.Text = employee.middleName;
                lblLastName.Text = employee.lastName;
                lblAddress.Text = employee.address;
                lblAddress2.Text = employee.address2;
                lblCity.Text = employee.city;
                lblState.Text = employee.state;
                lblZipCode.Text = employee.zipCode;
                lblTaxID.Text = employee.taxID;
                lblHireDate.Text = employee.hireDate.ToString();
                lblEndDate.Text = employee.endDate.ToString();
                lblManagerID.Text = employee.managerID.ToString();
            }
            else
            {
                Response.Redirect("EmployeeRegistration.aspx");
            }
        }

        protected void btnChange_Click(object sender, EventArgs e)
        {
            Response.Redirect("EmployeeRegistration.aspx");
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            Employee employee = new Employee();
            EmployeeTier tier = new EmployeeTier();

            employee.firstName = lblFirstName.Text;
            employee.middleName = lblMiddleName.Text;
            employee.lastName = lblLastName.Text;
            employee.address = lblAddress.Text;
            employee.address2 = lblAddress2.Text;
            employee.city = lblCity.Text;
            employee.state = lblState.Text;
            employee.zipCode = lblZipCode.Text;
            employee.taxID = lblTaxID.Text;
            employee.hireDate = DateTime.Parse(lblHireDate.Text);
            employee.endDate = DateTime.Parse(lblEndDate.Text);
            employee.managerID = int.Parse(lblManagerID.Text);

            tier.insertEmployee(employee);

            Response.Redirect("ListAllEmployees.aspx");
        }
    }
}