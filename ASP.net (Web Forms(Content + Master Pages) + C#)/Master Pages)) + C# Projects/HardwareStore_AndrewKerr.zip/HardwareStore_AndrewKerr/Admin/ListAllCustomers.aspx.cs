﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using HardwareStore_AndrewKerr.DataAccess;

namespace HardwareStore_AndrewKerr.Admin
{
    public partial class ListAllCustomers : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            CustomerTier tier = new CustomerTier();
            List<Customer> customerList = new List<Customer>();

            customerList = tier.getAllCustomers();

            grdCustomers.DataSource = customerList;
            grdCustomers.DataBind();
        }

    }
}