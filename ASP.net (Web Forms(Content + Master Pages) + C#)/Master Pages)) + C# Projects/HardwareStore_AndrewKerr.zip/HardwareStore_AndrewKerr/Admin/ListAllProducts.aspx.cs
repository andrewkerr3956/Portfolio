﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using HardwareStore_AndrewKerr.DataAccess;

namespace HardwareStore_AndrewKerr.Admin
{
    public partial class ListAllProducts : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            ProductTier tier = new ProductTier();
            List<Product> productList = new List<Product>();

            productList = tier.getAllProducts();

            grdProducts.DataSource = productList;
            grdProducts.DataBind();

        }

    }
}