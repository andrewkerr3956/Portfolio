﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace HardwareStore_AndrewKerr
{
    public partial class CustomerRegistration : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["Customer"] != null)
            {
                Customer customer = (Customer)Session["Customer"];

                txtFirstName.Text = customer.firstName;
                txtMiddleName.Text = customer.middleName;
                txtLastName.Text = customer.lastName;
                txtAddress.Text = customer.address;
                txtAddress2.Text = customer.address2;
                txtCity.Text = customer.city;
                txtState.Text = customer.state;
                txtZipCode.Text = customer.zipCode.ToString();

                Session["Customer"] = null;
            }
        }

        protected void btnClear_Click(object sender, EventArgs e)
        {
            txtFirstName.Text = "";
            txtMiddleName.Text = "";
            txtLastName.Text = "";
            txtAddress.Text = "";
            txtAddress2.Text = "";
            txtCity.Text = "";
            txtState.Text = "";
            txtZipCode.Text = "";
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            Customer customer = new Customer();
            customer.firstName = txtFirstName.Text;
            customer.middleName = txtMiddleName.Text;
            customer.lastName = txtLastName.Text;
            customer.address = txtAddress.Text;
            customer.address2 = txtAddress2.Text;
            customer.city = txtCity.Text;
            customer.state = txtState.Text;
            customer.zipCode = int.Parse(txtZipCode.Text);

            Session["Customer"] = customer;

            Response.Redirect("RegistrationConf.aspx");

        }
    }
}