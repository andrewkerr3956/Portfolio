﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Configuration;

namespace HardwareStore_AndrewKerr.DataAccess
{
    public class CustomerTier : BaseTier
    {
        public CustomerTier() : base()
        {

        }

        public List<Customer> getAllCustomers()
        {
            List<Customer> customerList = null;
            Customer customer;

            query = "SELECT * FROM CustomerInformation;";
            conn = new SqlConnection(connectionString);
            cmd = new SqlCommand(query, conn);

            try
            {

                conn.Open();
                reader = cmd.ExecuteReader();
                if (reader.HasRows)
                {
                    customerList = new List<Customer>();
                    while (reader.Read())
                    {
                        customer = new Customer();
                        customer.custID = (int)reader["CustID"];
                        customer.firstName = (string)reader["FirstName"];
                       if (reader["MiddleName"] != DBNull.Value)
                        {
                            customer.middleName = (string)reader["MiddleName"];
                        }
                        else
                        {
                            customer.middleName = "N/A";
                        }
                        customer.lastName = (string)reader["LastName"];
                        customer.address = (string)reader["Address"];
                        if (reader["Address2"] != DBNull.Value)
                        {
                            customer.address2 = (string)reader["Address2"];
                        }
                        else
                        {
                            customer.address2 = "N/A";
                        }
                        customer.city = (string)reader["City"];
                        customer.state = (string)reader["State"];
                        customer.zipCode = (int)reader["Zip"];

                        customerList.Add(customer);
                    }
                }
            }
            catch (SqlException ex) { 
                throw new Exception(ex.Message);
            }
            finally
            {
                conn.Close();
            }
            
            // return the list back to the presentation tier.
            return customerList;
        }

        public bool insertCustomer(Customer customer)
        {
            int row = 0;

            query = "INSERT INTO CustomerInformation " +
                "(FirstName, MiddleName, LastName, Address, Address2, City, State, Zip) " +
                "VALUES(@FName, @MName, @LName, @Address, @Address2, @City, @State, @Zip);";

            conn = new SqlConnection(connectionString);
            cmd = new SqlCommand(query, conn);

            cmd.Parameters.Add("@FName", SqlDbType.NVarChar, 50).Value = customer.firstName;
            if (customer.middleName != null)
            {
                cmd.Parameters.Add("@MName", SqlDbType.NVarChar, 50).Value = customer.middleName;
            }
            else
            {
                cmd.Parameters.Add("@MName", SqlDbType.NVarChar, 50).Value =DBNull.Value;

            }
            cmd.Parameters.Add("@LName", SqlDbType.NVarChar, 50).Value = customer.lastName;
            cmd.Parameters.Add("@Address", SqlDbType.NVarChar, 50).Value = customer.address;
            if (customer.address2 != null)
            {
                cmd.Parameters.Add("@Address2", SqlDbType.NVarChar, 50).Value = customer.address2;
            }
            else
            {
                cmd.Parameters.Add("@Address2", SqlDbType.NVarChar, 50).Value = DBNull.Value;

            }
            cmd.Parameters.Add("@City", SqlDbType.NVarChar, 50).Value = customer.city;
            cmd.Parameters.Add("@State", SqlDbType.NVarChar, 50).Value = customer.state;
            cmd.Parameters.Add("@Zip", SqlDbType.Int).Value = customer.zipCode;

            try
            {
                conn.Open();
                //You use Execute Non Query when it will only return the number of
                // rows affect.
                row = cmd.ExecuteNonQuery();

                if (row > 0)
                {
                    success = true;
                }
                else
                {
                    success = false;
                }
            }
            catch(SqlException ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                conn.Close();
            }

            return success;
        }

        public bool updateCustomer (Customer customer)
        {
            int row = 0;
            query = "UPDATE CustomerInformation " +
                    "SET FirstName = @FirstName, MiddleName = @MiddleName, LastName = @LastName, Address = @Address, Address2 = @Address2, City = @City, State = @State, Zip = @Zip " +
                    "WHERE CustID = @CustID;";

            conn = new SqlConnection(connectionString);
            cmd = new SqlCommand(query, conn);

            cmd.Parameters.Add("@EmployeeID", SqlDbType.Int).Value = customer.custID;
            cmd.Parameters.Add("@FirstName", SqlDbType.NVarChar, 50).Value = customer.firstName;
            cmd.Parameters.Add("@MiddleName", SqlDbType.NVarChar, 50).Value = customer.middleName;
            cmd.Parameters.Add("@LastName", SqlDbType.NVarChar, 50).Value = customer.lastName;
            cmd.Parameters.Add("@Address", SqlDbType.NVarChar, 50).Value = customer.address;
            cmd.Parameters.Add("@Address2", SqlDbType.NVarChar, 50).Value = customer.address2;
            cmd.Parameters.Add("@City", SqlDbType.NVarChar, 50).Value = customer.city;
            cmd.Parameters.Add("@State", SqlDbType.NVarChar, 50).Value = customer.state;
            cmd.Parameters.Add("@Zip", SqlDbType.NVarChar, 50).Value = customer.zipCode;

            try
            {
                conn.Open();
                row = cmd.ExecuteNonQuery();

                if (row > 0)
                {
                    success = true;
                }
                else
                {
                    success = false;
                }
            }
            catch (SqlException ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                conn.Close();
            }

            return success;
       
        }

        public bool deleteCustomer(int custID)
        {
            int row = 0;
            query = "DELETE FROM CustomerInformation " +
                    "WHERE CustID = @CustID;";

            conn = new SqlConnection(connectionString);
            cmd = new SqlCommand(query, conn);

            cmd.Parameters.Add("@CustID", SqlDbType.Int).Value = custID;

            try
            {
                row = cmd.ExecuteNonQuery();

                if (row > 0)
                {
                    success = true;
                }
                else
                {
                    success = false;
                }
            }
            catch (SqlException ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                conn.Close();
            }

            return success;
        }

    }
}