﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Configuration;

namespace HardwareStore_AndrewKerr.DataAccess
{
    public class EmployeeTier : BaseTier
    {
        public EmployeeTier() : base()
        {

        }
        public List<Employee> getAllEmployees()
        {

            List<Employee> employeeList = null;
            Employee employee;

            query = "SELECT * FROM Employee;";
            conn = new SqlConnection(connectionString);
            cmd = new SqlCommand(query, conn);

            try
            {
                conn.Open();
                reader = cmd.ExecuteReader();

                if (reader.HasRows)
                {

                    employeeList = new List<Employee>();
                    while (reader.Read())
                    {
                        employee = new Employee();

                        employee.employeeID = (int)reader["EmployeeID"];
                        employee.firstName = (string)reader["FirstName"];
                        if (reader["MiddleName"] != DBNull.Value)
                        {
                            employee.middleName = (string)reader["MiddleName"];
                        }
                        else
                        {
                            employee.middleName = "N/A";
                        }
                        employee.lastName = (string)reader["LastName"];
                        employee.address = (string)reader["Address"];
                        if (reader["Address2"] != DBNull.Value)
                        {
                            employee.address2 = (string)reader["Address2"];
                        }
                        else
                        {
                            employee.address2 = "N/A";
                        }
                        employee.city = (string)reader["City"];
                        employee.state = (string)reader["State"];
                        employee.zipCode = (string)reader["Zip"];
                        if (reader["TaxID"] != DBNull.Value)
                        {
                            employee.taxID = (string)reader["TaxID"];
                        }
                        else
                        {
                            employee.taxID = "N/A";
                        }

                        if (reader["HireDate"] != DBNull.Value)
                        {
                            employee.hireDate = (DateTime)reader["HireDate"];
                        }
                        else
                        {
                            employee.hireDate = DateTime.Parse("1/1/2000");
                        }
                     
                        if (reader["EndDate"] != DBNull.Value)
                        {
                            employee.endDate = (DateTime)reader["EndDate"];
                        }
                        else
                        {
                            employee.endDate = DateTime.Parse("12/31/2050");
                        }

                        if (reader["ManagerID"] != DBNull.Value)
                        {
                            employee.managerID = (int)reader["ManagerID"];
                        }
                        else
                        {
                            employee.managerID = 0;
                        }

                        employeeList.Add(employee);

                    }
                }
            }
            catch (SqlException ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                conn.Close();
            }

            return employeeList;
        }

        public bool insertEmployee (Employee employee)
        {
            int row = 0;

            query = "INSERT INTO Employee " +
                    "(FirstName, MiddleName, LastName, Address, Address2, City, State, Zip, TaxID, HireDate, EndDate, ManagerID) " +
                    "VALUES(@FirstName, @MiddleName, @LastName, @Address, @Address2, @City, @State, @Zip, @TaxID, @HireDate, @EndDate, @ManagerID);";
            conn = new SqlConnection(connectionString);
            cmd = new SqlCommand(query, conn);

            cmd.Parameters.Add("@FirstName", SqlDbType.NVarChar, 50).Value = employee.firstName;
            if (employee.middleName != null)
            {
                cmd.Parameters.Add("@MiddleName", SqlDbType.NVarChar, 50).Value = employee.middleName;
            }
            else
            {
                cmd.Parameters.Add("@MiddleName", SqlDbType.NVarChar, 50).Value = DBNull.Value;
            }
            cmd.Parameters.Add("@LastName", SqlDbType.NVarChar, 50).Value = employee.lastName;
            cmd.Parameters.Add("@Address", SqlDbType.NVarChar, 50).Value = employee.address;
            if (employee.address2 != null)
            {
                cmd.Parameters.Add("@Address2", SqlDbType.NVarChar, 50).Value = employee.address2;
            }
            else
            {
                cmd.Parameters.Add("@Address2", SqlDbType.NVarChar, 50).Value = DBNull.Value;
            }
            cmd.Parameters.Add("@City", SqlDbType.NVarChar, 50).Value = employee.city;
            cmd.Parameters.Add("@State", SqlDbType.NVarChar, 50).Value = employee.state;
            cmd.Parameters.Add("@Zip", SqlDbType.NVarChar, 50).Value = employee.zipCode;
            cmd.Parameters.Add("@TaxID", SqlDbType.NVarChar, 50).Value = employee.taxID;
            cmd.Parameters.Add("@HireDate", SqlDbType.Date).Value = employee.hireDate;
            if (employee.endDate.ToString() != null)
            {
                cmd.Parameters.Add("@EndDate", SqlDbType.Date).Value = employee.endDate;
            }
            else
            {
                cmd.Parameters.Add("@EndDate", SqlDbType.Date).Value = DBNull.Value;
            }
            cmd.Parameters.Add("@ManagerID", SqlDbType.Int).Value = employee.managerID;

            try
            {
               
                conn.Open();

                row = cmd.ExecuteNonQuery();

                if (row > 0)
                {
                    success = true;
                }
                else
                {
                    success = false;
                }

            }
            catch (SqlException ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
               conn.Close();
            }

            return success;
        }

        public bool updateEmployee(Employee employee)
        {
            int row = 0;

            query = "INSERT INTO Employee " +
                    "SET(FirstName = @FirstName, MiddleName = @MiddleName, LastName = @LastName, Address = @Address, Address2 = @Address2, City = @City, State = @State, Zip = @Zip, TaxID = @TaxID, HireDate = @HireDate, EndDate = @EndDate, ManagerID = @ManagerID) " +
                    "WHERE EmployeeID = @EmployeeID;";

            conn = new SqlConnection(connectionString);
            cmd = new SqlCommand(query, conn);

            cmd.Parameters.Add("@EmployeeID", SqlDbType.Int).Value = employee.employeeID;
            cmd.Parameters.Add("@FirstName", SqlDbType.NVarChar, 50).Value = employee.firstName;
            cmd.Parameters.Add("@MiddleName", SqlDbType.NVarChar, 50).Value = employee.middleName;
            cmd.Parameters.Add("@LastName", SqlDbType.NVarChar, 50).Value = employee.lastName;
            cmd.Parameters.Add("@Address", SqlDbType.NVarChar, 50).Value = employee.address;
            cmd.Parameters.Add("@Address2", SqlDbType.NVarChar, 50).Value = employee.address2;
            cmd.Parameters.Add("@City", SqlDbType.NVarChar, 50).Value = employee.city;
            cmd.Parameters.Add("@State", SqlDbType.NVarChar, 50).Value = employee.state;
            cmd.Parameters.Add("@Zip", SqlDbType.NVarChar, 50).Value = employee.zipCode;
            cmd.Parameters.Add("@TaxID", SqlDbType.NVarChar, 50).Value = employee.taxID;
            cmd.Parameters.Add("@HireDate", SqlDbType.DateTime, 50).Value = employee.hireDate;
            cmd.Parameters.Add("@EndDate", SqlDbType.DateTime, 50).Value = employee.endDate;
            cmd.Parameters.Add("@ManagerID", SqlDbType.Int).Value = employee.managerID;

            try
            {
                conn.Open();

                row = cmd.ExecuteNonQuery();

                if ( row > 0 )
                {
                    success = true;
                }
                else
                {
                    success = false;
                }
            }
            catch (SqlException ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                conn.Close();
            }

            return success;
        }

        public bool deleteEmployee(int employeeID)
        {
            int row = 0;
            query = "DELETE FROM Employee " +
                    "WHERE EmployeeID = @EmployeeID;";

            conn = new SqlConnection(connectionString);
            cmd = new SqlCommand(query, conn);

            cmd.Parameters.Add("@EmployeeID", SqlDbType.Int).Value = employeeID;
            try
            {
                conn.Open();

                row = cmd.ExecuteNonQuery();

                if ( row > 0 ) 
                {

                    success = true;
                
                }
                else
                {
                    success = false;

                }

            }
            catch (SqlException ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                conn.Close();
            }

            return success;
        }

    }

   }
