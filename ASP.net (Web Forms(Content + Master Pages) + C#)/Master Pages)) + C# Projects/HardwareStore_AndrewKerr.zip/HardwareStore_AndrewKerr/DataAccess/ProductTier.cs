﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Configuration;

namespace HardwareStore_AndrewKerr.DataAccess
{
    public class ProductTier : BaseTier
    {
        public ProductTier() : base()
        {

        }

        public bool insertProduct(Product product)
        {
            success = true;
            query = "INSERT INTO ProductInformation (ProductName, ProductDetails, QuantityOnHand, CurrentPrice, ProductImage) " +
                    "VALUES(@ProductName, @ProductDetails, @QuantityOnHand, @CurrentPrice, @ProductImage);";
            conn = new SqlConnection(connectionString);
            cmd = new SqlCommand(query, conn);

            int rows;

            cmd.Parameters.Add("@ProductName", SqlDbType.NVarChar, 50).Value = product.productName;
            cmd.Parameters.Add("@ProductDetails", SqlDbType.NVarChar, 50).Value = product.productDetails;
            cmd.Parameters.Add("@QuantityOnHand", SqlDbType.Int).Value = product.quantityOnHand;
            cmd.Parameters.Add("@CurrentPrice", SqlDbType.Money).Value = product.currentPrice;
            if (product.productImage != null)
            {
                cmd.Parameters.Add("@ProductImage", SqlDbType.Image).Value = product.productImage;
            }
            else
            {
                cmd.Parameters.Add("@ProductImage", SqlDbType.Image).Value = DBNull.Value;
            }

            try
            {
                conn.Open();
                rows = cmd.ExecuteNonQuery();

                if (rows >= 1)
                {
                    success = true;
                }
                else
                {
                    success = false;
                }
            }
            catch (SqlException ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                conn.Close();
            }

            return success;

        }

        public byte[] getImage(int imageID)
        {
            byte[] productImage = null;
            query = "SELECT ProductImage " +
                    "FROM ProductInformation " +
                    "WHERE ProductID = @ID;";
            conn = new SqlConnection(connectionString);
            cmd = new SqlCommand(query, conn);
            cmd.Parameters.Add("@ID", SqlDbType.Int).Value = imageID;

            try
            {
                conn.Open();
                var data = cmd.ExecuteScalar();
                if ( data != DBNull.Value )
                {
                    productImage = (byte[])data;
                }
                else
                {
                    productImage= null;
                }
            }
            catch (SqlException ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                conn.Close();
            }

            return productImage;
        }

        public List<Product> getAllProducts()
        {
            List<Product> productList = null;
            Product product;

            query = "SELECT * FROM ProductInformation;";
            conn = new SqlConnection(connectionString);
            cmd = new SqlCommand(query, conn);


            try
            {
                conn.Open();
                reader = cmd.ExecuteReader();
                if (reader.HasRows)
                {
                    productList = new List<Product>();
                    while (reader.Read())
                    {
                        product = new Product();
                        product.productID = (int)reader["ProductID"];
                        product.productName = (string)reader["ProductName"];
                        if (reader["ProductDetails"] != DBNull.Value)
                        {
                            product.productDetails = (string)reader["ProductDetails"];
                        }
                        else
                        {
                            product.productDetails = "N/A";
                        }

                        if(reader["QuantityOnHand"] != DBNull.Value)
                        {
                            product.quantityOnHand = (int)reader["QuantityOnHand"];

                        }
                        else
                        {
                            product.quantityOnHand = (int)0;
                        }

                        if (reader["CurrentPrice"] != DBNull.Value)
                        {
                            product.currentPrice = (decimal)reader["CurrentPrice"]; 
                        }
                        else
                        {
                            product.currentPrice = (decimal)0.0;
                        }

                        if (reader["ProductImage"] != DBNull.Value)
                        {
                            product.productImage = (byte[])reader["ProductImage"];
                        }
                        else
                        {
                            product.productImage = null;
                        }
                        


                        productList.Add(product);
                    }
                }
            }
            catch (SqlException ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                conn.Close();
            }

            return productList;

        }

        public bool updateProduct(Product product)
        {
            query = "UPDATE ProductInformation " +
                    "SET (ProductName = @ProductName, ProductDetails = @ProductDetails, QuantityOnHand = @QuantityOnHand, CurrentPrice = @CurrentPrice, ProductImage = @ProductImage) " +
                    "WHERE ProductID = @ProductID;";
            conn = new SqlConnection(connectionString);
            cmd = new SqlCommand(query, conn);
            int row = 0;

            try
            {
                conn.Open();
                cmd.Parameters.Add("@ProductID", SqlDbType.Int).Value = product.productID;
                cmd.Parameters.Add("@ProductName", SqlDbType.NVarChar, 50).Value = product.productName;
                cmd.Parameters.Add("@ProductDetails", SqlDbType.NVarChar, 50).Value = product.productDetails;
                cmd.Parameters.Add("@QuantityOnHand", SqlDbType.Int).Value = product.quantityOnHand;
                cmd.Parameters.Add("@CurrentPrice", SqlDbType.Money).Value = product.currentPrice;
                if (product.productImage != null)
                {
                    cmd.Parameters.Add("@ProductImage", SqlDbType.Image).Value = product.productImage;
                }
                else
                {
                    cmd.Parameters.Add("@ProductImage", SqlDbType.Image).Value = DBNull.Value;
                }
                
            }
            catch (SqlException ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                conn.Close();
                row = cmd.ExecuteNonQuery();
                if (row >= 1)
                {
                    success = true;
                }
                else
                {
                    success = false;
                }
            }

            return success;
        }

        public bool deleteProduct(int productID)
        {
            query = "DELETE FROM ProductInformation " +
                    "WHERE ProductID = @ProductID;";
            conn = new SqlConnection(connectionString);
            cmd = new SqlCommand(query, conn);
            int row = 0;

            try
            {
                conn.Open();
                cmd.Parameters.Add("@ProductID", SqlDbType.Int).Value = productID;
            }
            catch (SqlException ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                conn.Close();
                row = cmd.ExecuteNonQuery();
                if (row >= 1)
                {
                    success = true;
                }
                else
                {
                    success = false;
                }
            }

            return success;
        }

        public Product getProductById(int productID)
        {
            query = "SELECT * FROM ProductInformation " +
                    "WHERE ProductID = @ProductID;";
            conn = new SqlConnection(connectionString);
            cmd = new SqlCommand(query, conn);

            try
            {
                conn.Open();
                cmd.Parameters.Add("@ProductID", SqlDbType.Int).Value = productID;

                // activate reader now that we know the productid
                cmd.ExecuteReader();
                Product product = new Product();
                product.productName = (string)reader["ProductName"];
                product.productDetails = (string)reader["ProductDetails"];
                product.quantityOnHand = (int)reader["QuantityOnHand"];
                product.currentPrice = (decimal)reader["CurrentPrice"];
                product.productImage = (byte[])reader["ProductImage"];

                return product;

            }
            catch (SqlException ex)
            {
                throw new Exception(ex.Message);
            }
            finally
            {
                conn.Close();
            }

        }

    }




}