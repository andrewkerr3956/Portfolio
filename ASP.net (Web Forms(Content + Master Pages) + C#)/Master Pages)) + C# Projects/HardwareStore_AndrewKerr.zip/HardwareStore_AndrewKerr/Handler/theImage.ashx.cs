﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using HardwareStore_AndrewKerr.DataAccess;

namespace HardwareStore_AndrewKerr
{
    /// <summary>
    /// Summary description for theImage
    /// </summary>
    public class theImage : IHttpHandler
    {

        public void ProcessRequest(HttpContext context)
        {
            byte[] theImage;
            ProductTier theTier = new ProductTier();
            //Using the information from the URL, get the product ID
            Int32 imageID = Int32.Parse(context.Request.QueryString["ID"]);
           
            //Using the productID, get the image of the product from the data tier
            theImage = theTier.getImage(imageID);

            //Send the binary data to the URL requesting it.
            context.Response.BinaryWrite(theImage);
        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
    }
}