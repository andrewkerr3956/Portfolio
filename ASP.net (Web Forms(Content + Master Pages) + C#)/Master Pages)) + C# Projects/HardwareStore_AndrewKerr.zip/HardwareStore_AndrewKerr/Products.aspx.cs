﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using HardwareStore_AndrewKerr.DataAccess;

namespace HardwareStore_AndrewKerr
{
    public partial class Products : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Table productTable = null;
            ProductTier tier = new ProductTier();
            List<Product> productList = tier.getAllProducts();
            foreach(Product p in productList)
            {
                int prodnum = productList.Count;
                productTable = buildTable(productList[prodnum]);
                pnlProducts.Controls.Add(productTable);
            }
            

            
        }

        private Table buildTable(Product product)
        {
            Table productTable = new Table();
            TableRow tr = new TableRow();

            TableCell td = new TableCell();
            Label theLabel = new Label();
            Image productImage = new Image();

            // Add the Product Name
            theLabel.Text = product.productName;
            theLabel.Font.Bold = true;
            theLabel.Font.Size = 20;
            td.CssClass = "text-center";
            td.Controls.Add(theLabel);
            tr.Cells.Add(td);
            productTable.Rows.Add(tr);

            // Add the Product Image
            tr = new TableRow();
            td = new TableCell();
            productImage.ImageUrl = "/Handler/theImage.ashx?ID=" + product.productID.ToString();
            productImage.CssClass = "img-fluid";
            td.CssClass = "text-center";
            td.Controls.Add(productImage);
            tr.Cells.Add(td);
            productTable.Rows.Add(tr);

            // Add the Product Details
            theLabel = new Label();
            tr = new TableRow();
            td = new TableCell();
            theLabel.Text = product.productDetails;
            td.Controls.Add(theLabel);
            tr.Cells.Add(td);
            productTable.Rows.Add(tr);

            // Add the Product Quantity
            theLabel = new Label();
            tr = new TableRow();
            td = new TableCell();
            theLabel.Text = "<strong> Quantity Remaining: " + product.quantityOnHand.ToString() + "</strong>";
            td.CssClass = "text-center";
            td.Controls.Add(theLabel);
            tr.Cells.Add(td);
            productTable.Rows.Add(tr);

            // Add the Product Price
            theLabel = new Label();
            tr = new TableRow();
            td = new TableCell();
            theLabel.Text = "<strong> Price: $" + product.currentPrice.ToString() + "</strong>";
            td.CssClass = "text-center";
            td.Controls.Add(theLabel);
            tr.Cells.Add(td);
            productTable.Rows.Add(tr);

            // Add to Cart Button
            tr = new TableRow();
            td = new TableCell();
            Button addToCart = new Button();
            td.CssClass = "text-center";
            addToCart.ID = product.productID.ToString();
            addToCart.Text = "Add to Cart";
            addToCart.CssClass = "btn btn-success";
            addToCart.Click += new EventHandler(btnaddToCart_Click);

            td.Controls.Add(addToCart);
            tr.Cells.Add(td);
            productTable.Rows.Add(tr);

            return productTable;
        }

        protected void btnaddToCart_Click(object sender, EventArgs e)
        {
            lblClicked.Text = "You clicked me!";
        }
    }
}